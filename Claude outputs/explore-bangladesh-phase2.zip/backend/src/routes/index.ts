import { Router } from 'express';
import {
  getDestination,
  getDestinations,
  getFeatured,
  getPins,
  getPopular,
} from '../controllers/destination.controller.js';
import {
  getCategories,
  getDistrict,
  getDistricts,
  getDivision,
  getDivisions,
} from '../controllers/reference.controller.js';
import { health, overview } from '../controllers/system.controller.js';
import { ensureDb } from '../middleware/ensureDb.js';
import { validate } from '../middleware/validate.js';
import { destinationListQuery, showcaseQuery, slugParams } from '../validators/destination.validators.js';
import { districtListQuery } from '../validators/reference.validators.js';

/** All v1 routes. Feature routers (score, auth, me, admin…) mount here in later phases. */
export const v1Router = Router();

// System
v1Router.get('/health', health);
v1Router.get('/stats/overview', ensureDb, overview);

// Reference data
v1Router.get('/divisions', ensureDb, getDivisions);
v1Router.get('/divisions/:slug', validate('params', slugParams), ensureDb, getDivision);
v1Router.get('/districts', validate('query', districtListQuery), ensureDb, getDistricts);
v1Router.get('/districts/:slug', validate('params', slugParams), ensureDb, getDistrict);
v1Router.get('/categories', ensureDb, getCategories);

// Destinations — fixed paths are registered before /:slug
v1Router.get('/destinations', validate('query', destinationListQuery), ensureDb, getDestinations);
v1Router.get('/destinations/pins', ensureDb, getPins);
v1Router.get('/destinations/featured', validate('query', showcaseQuery), ensureDb, getFeatured);
v1Router.get('/destinations/popular', validate('query', showcaseQuery), ensureDb, getPopular);
v1Router.get('/destinations/:slug', validate('params', slugParams), ensureDb, getDestination);
