/** Response envelope used by every backend endpoint. */
export type ApiSuccess<T> = {
  success: true
  data: T
  meta?: PaginationMeta
}

export type ApiFailure = {
  success: false
  error: { code: string; message: string; details?: unknown }
}

export type PaginationMeta = {
  page: number
  limit: number
  total: number
  totalPages: number
}

export type OverviewStats = {
  totalDestinations: number
  totalDistricts: number
  totalDivisions: number
  totalCategories: number
}

export type Image = { url: string; publicId?: string; alt?: string }

export type Division = {
  id: string
  name: string
  nameBn: string
  slug: string
  description: string | null
  image: Image | null
  districtCount: number
  destinationCount: number
}

export type District = {
  id: string
  name: string
  nameBn: string
  slug: string
  division: { id: string; name: string; nameBn: string; slug: string }
  location: { type: 'Point'; coordinates: [number, number] } | null
  destinationCount: number
}

export type Category = {
  id: string
  name: string
  nameBn: string
  slug: string
  icon: string | null
  destinationCount: number
}

export type RefSummary = { id: string; slug: string; name: string; nameBn: string }
export type CategorySummary = RefSummary & { icon: string | null }
export type GeoPoint = { type: 'Point'; coordinates: [number, number] }

export type DestinationCard = {
  id: string
  slug: string
  name: string
  nameBn: string
  shortDescription: string
  shortDescriptionBn: string | null
  upazila: { name?: string; nameBn?: string } | null
  division: RefSummary
  district: RefSummary
  category: CategorySummary
  featuredImage: Image | null
  location: GeoPoint | null
  isFeatured: boolean
}

export type DestinationDetail = DestinationCard & {
  description: string | null
  descriptionBn: string | null
  significance: string | null
  significanceBn: string | null
  visitingInfo: Partial<Record<'bestTime' | 'openingHours' | 'entryFee' | 'howToReach' | 'tips', string>> | null
  images: Image[]
  nearby: Array<DestinationCard & { distanceKm: number | null }>
}

/** Compact record for map pins. */
export type DestinationPin = {
  id: string
  slug: string
  name: string
  nameBn: string
  divisionId: string
  districtId: string
  categoryId: string
  coordinates: [number, number] | null
}

export type DivisionDetail = Omit<Division, 'districtCount'> & {
  districts: Array<{ id: string; name: string; nameBn: string; slug: string; destinationCount: number }>
}

export type DistrictDetail = Omit<District, 'location'> & {
  location: GeoPoint | null
  image: Image | null
}

export type Paginated<T> = { items: T[]; meta: PaginationMeta }
