import { MapPin } from 'lucide-react'
import { Link } from 'react-router'
import { CategoryArt } from '@/components/destination/CategoryArt'
import { VisitedToggle } from '@/components/destination/VisitedToggle'
import { useI18n } from '@/i18n/useI18n'
import type { DestinationCard as Destination } from '@/types/api'

export function DestinationCard({ destination, meta }: { destination: Destination; meta?: string }) {
  const { pick } = useI18n()
  const name = pick(destination.name, destination.nameBn)

  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border bg-white transition-shadow hover:shadow-md">
      <CategoryArt category={destination.category} image={destination.featuredImage} className="h-32" />
      <div className="absolute right-3 top-3">
        <VisitedToggle id={destination.id} name={name} className="shadow-sm" />
      </div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="font-bold leading-snug text-brand-950">
          <Link to={`/destinations/${destination.slug}`} className="after:absolute after:inset-0 after:content-['']">
            {name}
          </Link>
        </h3>
        <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="size-3.5 shrink-0" aria-hidden />
          {pick(destination.district.name, destination.district.nameBn)} · {pick(destination.category.name, destination.category.nameBn)}
        </p>
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {pick(destination.shortDescription, destination.shortDescriptionBn)}
        </p>
        {meta && <p className="mt-auto pt-3 text-xs font-semibold text-brand-700">{meta}</p>}
      </div>
    </article>
  )
}
