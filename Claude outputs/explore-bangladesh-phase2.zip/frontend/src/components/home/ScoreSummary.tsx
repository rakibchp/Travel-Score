import { CheckCircle2, Flag, MapPin, Trophy } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import { SectionHeading } from '@/components/common/SectionHeading'
import { ErrorState } from '@/components/common/StateViews'
import { Container } from '@/components/layout/Container'
import { buttonVariants } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useOverviewStats } from '@/hooks/useReferenceData'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { percentage } from '@/utils/format'

function StatCard({ icon, label, value, hint }: { icon: ReactNode; label: string; value: ReactNode; hint?: string }) {
  return (
    <Card className="p-4 sm:p-5">
      <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground [&_svg]:size-4">
        {icon}
        {label}
      </div>
      <p className="mt-3 text-2xl font-extrabold tracking-tight text-brand-950 sm:text-3xl">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </Card>
  )
}

/**
 * Personal progress summary. For guests the visited count comes from the list in
 * this browser; Phase 3 replaces it with the server-calculated scorecard.
 */
export function ScoreSummary() {
  const { t, n } = useI18n()
  const { count: visited } = useVisited()
  const { data, isLoading, isError, error, refetch } = useOverviewStats()

  const total = data?.totalDestinations ?? 0
  const shown = Math.min(visited, total)
  const pct = percentage(shown, total)

  return (
    <section aria-labelledby="score-heading" className="py-14">
      <Container>
        <SectionHeading id="score-heading" eyebrow={t('home.progressEyebrow')} title={t('home.progressTitle')} description={t('home.progressBody')} />

        {isError ? (
          <ErrorState error={error} onRetry={() => void refetch()} title={t('home.totalsError')} />
        ) : isLoading ? (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {Array.from({ length: 4 }, (_, i) => (
              <Skeleton key={i} className="h-[120px]" />
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
              <StatCard icon={<Trophy className="text-accent-strong" />} label={t('home.statScore')} value={t('nav.points', { count: shown })} />
              <StatCard icon={<CheckCircle2 className="text-primary" />} label={t('home.statVisited')} value={n(shown)} />
              <StatCard
                icon={<MapPin className="text-primary" />}
                label={t('home.statRemaining')}
                value={n(Math.max(total - shown, 0))}
                hint={t('home.ofDestinations', { total })}
              />
              <StatCard icon={<Flag className="text-primary" />} label={t('home.statExplored')} value={`${n(pct)}%`} hint={t('home.ofBangladesh')} />
            </div>

            <Card className="mt-4 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold text-foreground">{t('home.progressLabel')}</span>
                  <span className="font-semibold text-brand-800">
                    {n(shown)} / {n(total)}
                  </span>
                </div>
                <div
                  className="mt-2 h-3 overflow-hidden rounded-full bg-muted"
                  role="progressbar"
                  aria-label={t('home.progressLabel')}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={pct}
                >
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-brand-600 to-brand-400 transition-[width] duration-700"
                    style={{ width: `${Math.max(pct, shown > 0 ? 2 : 0)}%` }}
                  />
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  {total === 0 ? t('home.progressEmptyDirectory') : shown === 0 ? t('home.progressNone') : t('home.progressSome')}
                </p>
              </div>
              <Link to="/explore" className={buttonVariants({ variant: 'secondary' })}>
                {t('home.markPlaces')}
              </Link>
            </Card>
          </>
        )}
      </Container>
    </section>
  )
}
