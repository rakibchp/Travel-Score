import { Languages, Menu, Trophy, X } from 'lucide-react'
import { useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router'
import { Container } from '@/components/layout/Container'
import { Logo } from '@/components/layout/Logo'
import { Button, buttonVariants } from '@/components/ui/button'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { cn } from '@/lib/utils'

function LanguageToggle({ className }: { className?: string }) {
  const { lang, setLang, t } = useI18n()
  return (
    <button
      type="button"
      onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
      aria-label={`${t('nav.language')}: ${t('nav.switchTo')}`}
      lang={lang === 'bn' ? 'en' : 'bn'}
      className={cn(
        'inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-full border px-3 text-sm font-semibold text-brand-800 transition-colors hover:bg-brand-50',
        className,
      )}
    >
      <Languages className="size-4" aria-hidden />
      {t('nav.switchTo')}
    </button>
  )
}

export function SiteHeader() {
  const { t } = useI18n()
  const { count } = useVisited()
  const { pathname } = useLocation()
  // The menu remembers which page it was opened on, so navigating closes it automatically.
  const [openOnPath, setOpenOnPath] = useState<string | null>(null)
  const open = openOnPath === pathname

  const items = [
    { to: '/', label: t('nav.home'), end: true },
    { to: '/explore', label: t('nav.explore') },
    { to: '/divisions', label: t('nav.divisions') },
    { to: '/scorecard', label: t('nav.scorecard') },
  ]

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-white/85 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between gap-4">
        <Logo />

        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  'rounded-full px-4 py-2 text-sm font-medium transition-colors',
                  isActive ? 'bg-brand-50 text-brand-800' : 'text-muted-foreground hover:text-foreground',
                )
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <LanguageToggle />
          <Link
            to="/scorecard"
            className="flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-semibold text-brand-800 hover:bg-brand-50"
            title={t('nav.scoreTitle')}
          >
            <Trophy className="size-4 text-accent-strong" aria-hidden />
            <span>{t('nav.points', { count })}</span>
          </Link>
          <Link to="/login" className={buttonVariants({ size: 'sm' })}>
            {t('nav.signIn')}
          </Link>
        </div>

        <div className="flex items-center gap-1 md:hidden">
          <LanguageToggle className="px-2.5" />
          <Button
            variant="ghost"
            size="icon"
            aria-label={open ? t('nav.closeMenu') : t('nav.openMenu')}
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpenOnPath(open ? null : pathname)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </Container>

      {open && (
        <div id="mobile-nav" className="animate-fade-up border-t bg-white md:hidden">
          <Container className="flex flex-col gap-1 py-3">
            {items.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn('rounded-xl px-4 py-3 text-base font-medium', isActive ? 'bg-brand-50 text-brand-800' : 'text-foreground hover:bg-muted')
                }
              >
                {item.label}
              </NavLink>
            ))}
            <Link to="/scorecard" className="flex items-center gap-2 rounded-xl px-4 py-3 text-base font-semibold text-brand-800">
              <Trophy className="size-4 text-accent-strong" aria-hidden /> {t('nav.points', { count })}
            </Link>
            <Link to="/login" className={cn(buttonVariants({ size: 'lg' }), 'mt-2 w-full')}>
              {t('nav.signIn')}
            </Link>
          </Container>
        </div>
      )}
    </header>
  )
}
