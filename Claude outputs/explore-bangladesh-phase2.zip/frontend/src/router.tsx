import { createBrowserRouter } from 'react-router'
import { RootLayout } from '@/layouts/RootLayout'
import { DestinationDetailPage } from '@/pages/DestinationDetailPage'
import { ExplorePage } from '@/pages/ExplorePage'
import { HomePage } from '@/pages/HomePage'
import { DistrictPage, DivisionPage, DivisionsPage } from '@/pages/RegionPages'
import { ComingSoonPage, NotFoundPage } from '@/pages/StatusPages'

/** Route map (see docs/ARCHITECTURE.md §5). Later-phase screens point at ComingSoonPage. */
export const router = createBrowserRouter([
  {
    element: <RootLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'explore', element: <ExplorePage /> },
      { path: 'destinations/:slug', element: <DestinationDetailPage /> },
      { path: 'divisions', element: <DivisionsPage /> },
      { path: 'divisions/:slug', element: <DivisionPage /> },
      { path: 'districts/:slug', element: <DistrictPage /> },
      { path: 'scorecard', element: <ComingSoonPage titleKey="status.scorecard" /> },
      { path: 'login', element: <ComingSoonPage titleKey="status.signIn" /> },
      { path: 'register', element: <ComingSoonPage titleKey="status.register" /> },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])
