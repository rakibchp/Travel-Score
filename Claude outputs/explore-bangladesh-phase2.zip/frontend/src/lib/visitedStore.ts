import { useCallback, useSyncExternalStore } from 'react'

/**
 * Guest visited list, kept in localStorage (key is versioned so the format can change).
 *
 * This is only the guest experience: from Phase 4, phone-verified users save to the
 * server and this list is imported into their account. Scores are always recomputed
 * by the server from these ids (Phase 3) — the browser never decides a score.
 */
const STORAGE_KEY = 'eb.visited.v1'
const MAX_IDS = 2000
const OBJECT_ID = /^[a-f0-9]{24}$/i

type Listener = () => void
const listeners = new Set<Listener>()

function read(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed: unknown = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === 'string' && OBJECT_ID.test(v)).slice(0, MAX_IDS) : []
  } catch {
    return []
  }
}

let snapshot: ReadonlySet<string> = new Set(read())

function write(ids: Set<string>) {
  snapshot = ids
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...ids]))
  } catch {
    // Storage full or disabled — keep the in-memory list for this session.
  }
  listeners.forEach((l) => l())
}

// Keep tabs in sync.
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === STORAGE_KEY) {
      snapshot = new Set(read())
      listeners.forEach((l) => l())
    }
  })
}

function subscribe(listener: Listener) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

export const visitedStore = {
  get: () => snapshot,
  toggle(id: string) {
    const next = new Set(snapshot)
    if (next.has(id)) next.delete(id)
    else if (next.size < MAX_IDS) next.add(id)
    write(next)
  },
  /** Drop ids that no longer exist (e.g. a destination was removed by an admin). */
  prune(validIds: Iterable<string>) {
    const valid = new Set(validIds)
    const next = new Set([...snapshot].filter((id) => valid.has(id)))
    if (next.size !== snapshot.size) write(next)
  },
  clear: () => write(new Set()),
}

export function useVisited() {
  const visited = useSyncExternalStore(subscribe, visitedStore.get, visitedStore.get)
  const toggle = useCallback((id: string) => visitedStore.toggle(id), [])
  return { visited, toggle, count: visited.size }
}
