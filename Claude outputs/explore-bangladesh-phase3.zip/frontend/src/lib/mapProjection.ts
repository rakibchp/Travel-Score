/**
 * Same Web Mercator projection used by scripts/build-map.mjs, so destination
 * coordinates land exactly on the pre-projected district paths.
 */
export type MapProjection = { minLng: number; maxMercY: number; scale: number; padding: number }

export type MapData = {
  attribution: string
  viewBox: [number, number, number, number]
  projection: MapProjection
  divisions: Array<{ slug: string; d: string; label: [number, number] }>
  districts: Array<{ slug: string; d: string; label: [number, number] }>
}

export type Box = { x: number; y: number; w: number; h: number }

const mercY = (lat: number) => (Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360)) * 180) / Math.PI

export function project([lng, lat]: [number, number], p: MapProjection): [number, number] {
  return [(lng - p.minLng) * p.scale + p.padding, (p.maxMercY - mercY(lat)) * p.scale + p.padding]
}

/** Bounding box of an SVG path made only of M/L/Z commands with absolute coordinates. */
export function pathBox(d: string): Box {
  let minX = Infinity
  let minY = Infinity
  let maxX = -Infinity
  let maxY = -Infinity
  const nums = d.match(/-?\d+(?:\.\d+)?/g) ?? []
  for (let i = 0; i + 1 < nums.length; i += 2) {
    const x = Number(nums[i])
    const y = Number(nums[i + 1])
    if (x < minX) minX = x
    if (x > maxX) maxX = x
    if (y < minY) minY = y
    if (y > maxY) maxY = y
  }
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY }
}

/** Grow a box by a fraction and match a target aspect ratio (w/h), keeping it centred. */
export function fitBox(box: Box, aspect: number, pad = 0.12): Box {
  let w = box.w * (1 + pad * 2)
  let h = box.h * (1 + pad * 2)
  if (w / h > aspect) h = w / aspect
  else w = h * aspect
  return { x: box.x + box.w / 2 - w / 2, y: box.y + box.h / 2 - h / 2, w, h }
}
