import { api } from '@/services/apiClient'
import type { Scorecard } from '@/types/api'

export const scoreApi = {
  /** Guest scorecard: the server validates the ids and calculates everything. */
  preview: (destinationIds: string[], suggestions = 6) =>
    api.post<Scorecard>('/score/preview', { destinationIds, suggestions }),
}
