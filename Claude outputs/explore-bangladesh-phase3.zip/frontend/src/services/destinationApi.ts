import { apiRequest, apiRequestEnvelope } from '@/services/apiClient'
import type {
  DestinationCard,
  DestinationDetail,
  DestinationPin,
  DistrictDetail,
  DivisionDetail,
  Paginated,
} from '@/types/api'

export type DestinationFilters = {
  q?: string
  division?: string
  district?: string
  category?: string
  ids?: string[]
  excludeIds?: string[]
  sort?: 'popular' | 'name'
  page?: number
  limit?: number
}

async function listDestinations(filters: DestinationFilters): Promise<Paginated<DestinationCard>> {
  const { ids, excludeIds, ...rest } = filters
  const envelope = await apiRequestEnvelope<DestinationCard[]>('/destinations', {
    query: {
      ...rest,
      ids: ids?.length ? ids.join(',') : undefined,
      excludeIds: excludeIds?.length ? excludeIds.join(',') : undefined,
    },
  })
  return {
    items: envelope.data,
    meta: envelope.meta ?? { page: 1, limit: envelope.data.length, total: envelope.data.length, totalPages: 1 },
  }
}

export const destinationApi = {
  list: listDestinations,
  pins: () => apiRequest<DestinationPin[]>('/destinations/pins'),
  featured: (limit = 8) => apiRequest<DestinationCard[]>('/destinations/featured', { query: { limit } }),
  popular: (limit = 8) => apiRequest<DestinationCard[]>('/destinations/popular', { query: { limit } }),
  detail: (slug: string) => apiRequest<DestinationDetail>(`/destinations/${encodeURIComponent(slug)}`),
  division: (slug: string) => apiRequest<DivisionDetail>(`/divisions/${encodeURIComponent(slug)}`),
  district: (slug: string) => apiRequest<DistrictDetail>(`/districts/${encodeURIComponent(slug)}`),
}
