import { Compass, Construction } from 'lucide-react'
import { Link } from 'react-router'
import { Container } from '@/components/layout/Container'
import { buttonVariants } from '@/components/ui/button'
import { useI18n } from '@/i18n/useI18n'
import type { TranslationKey } from '@/i18n/I18nProvider'

export function NotFoundPage() {
  const { t } = useI18n()
  return (
    <Container className="flex flex-col items-center py-24 text-center">
      <p className="text-6xl font-extrabold text-brand-200">404</p>
      <h1 className="mt-4 text-2xl font-bold text-brand-950">{t('status.notFoundTitle')}</h1>
      <p className="mt-2 max-w-md text-muted-foreground">{t('status.notFoundBody')}</p>
      <Link to="/" className={buttonVariants({ className: 'mt-8' })}>
        <Compass aria-hidden /> {t('common.backHome')}
      </Link>
    </Container>
  )
}

/** Used for routes whose screens are built in later phases, so navigation never dead-ends. */
export function ComingSoonPage({ titleKey }: { titleKey: TranslationKey }) {
  const { t } = useI18n()
  return (
    <Container className="flex flex-col items-center py-24 text-center">
      <div className="flex size-14 items-center justify-center rounded-full bg-brand-50 text-brand-700">
        <Construction className="size-7" aria-hidden />
      </div>
      <h1 className="mt-5 text-2xl font-bold text-brand-950">{t(titleKey)}</h1>
      <p className="mt-2 max-w-md text-muted-foreground">{t('status.comingSoonBody')}</p>
      <Link to="/" className={buttonVariants({ variant: 'outline', className: 'mt-8' })}>
        {t('common.backHome')}
      </Link>
    </Container>
  )
}
