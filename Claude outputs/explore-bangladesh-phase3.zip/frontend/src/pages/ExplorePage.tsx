import { ArrowRight, Search, X } from 'lucide-react'
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router'
import { CategoryIcon } from '@/components/common/CategoryIcon'
import { Pagination } from '@/components/common/Pagination'
import { EmptyState, ErrorState } from '@/components/common/StateViews'
import { DestinationListItem } from '@/components/destination/DestinationListItem'
import { VisitedToggle } from '@/components/destination/VisitedToggle'
import { Container } from '@/components/layout/Container'
import { ScoreBar } from '@/components/score/ScoreBar'
import { BangladeshMap, type MapFocus } from '@/components/map/BangladeshMap'
import { Skeleton } from '@/components/ui/skeleton'
import { useDestinationList, usePins } from '@/hooks/useDestinations'
import { useCategories } from '@/hooks/useReferenceData'
import { useRegions } from '@/hooks/useRegions'
import { useI18n } from '@/i18n/useI18n'
import { visitedStore, useVisited } from '@/lib/visitedStore'
import { cn } from '@/lib/utils'
import type { DestinationPin } from '@/types/api'

const PAGE_SIZE = 20
type VisitedFilter = 'all' | 'yes' | 'no'

export function ExplorePage() {
  const { t, n, pick } = useI18n()
  const [params, setParams] = useSearchParams()
  const { visited, count: visitedCount } = useVisited()
  const regions = useRegions()
  const categories = useCategories()
  const pins = usePins()

  const q = params.get('q') ?? ''
  const division = params.get('division') ?? ''
  const district = params.get('district') ?? ''
  const category = params.get('category') ?? ''
  const visitedFilter = (['yes', 'no'].includes(params.get('visited') ?? '') ? params.get('visited') : 'all') as VisitedFilter
  const page = Math.max(1, Number(params.get('page')) || 1)

  /** Update URL params; any filter change resets to page 1. */
  const update = (changes: Record<string, string | null>, keepPage = false) => {
    const next = new URLSearchParams(params)
    for (const [k, v] of Object.entries(changes)) {
      if (v) next.set(k, v)
      else next.delete(k)
    }
    if (!keepPage) next.delete('page')
    setParams(next, { replace: true })
  }

  // Debounced search box
  const [searchText, setSearchText] = useState(q)
  useEffect(() => setSearchText(q), [q])
  useEffect(() => {
    const id = setTimeout(() => {
      if (searchText.trim() !== q) update({ q: searchText.trim() || null })
    }, 300)
    return () => clearTimeout(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchText])

  // Forget ticks for destinations that no longer exist.
  useEffect(() => {
    if (pins.data) visitedStore.prune(pins.data.map((p) => p.id))
  }, [pins.data])

  const visitedIds = useMemo(() => [...visited], [visited])
  const skipList = visitedFilter === 'yes' && visitedIds.length === 0

  const list = useDestinationList(
    {
      q: q || undefined,
      division: division || undefined,
      district: district || undefined,
      category: category || undefined,
      ids: visitedFilter === 'yes' ? visitedIds : undefined,
      excludeIds: visitedFilter === 'no' && visitedIds.length ? visitedIds : undefined,
      page,
      limit: PAGE_SIZE,
    },
    !skipList,
  )

  /* ---------------- map state ---------------- */

  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [locate, setLocate] = useState<{ id: string; nonce: number } | null>(null)
  const mapRef = useRef<HTMLDivElement>(null)

  const categoryIdBySlug = useMemo(() => new Map((categories.data ?? []).map((c) => [c.slug, c.id])), [categories.data])
  const categoryById = useMemo(() => new Map((categories.data ?? []).map((c) => [c.id, c])), [categories.data])

  const mapPins = useMemo(() => {
    const all = pins.data ?? []
    const divisionId = division ? regions.divisionIdBySlug.get(division) : undefined
    const districtId = district ? regions.districtIdBySlug.get(district) : undefined
    const categoryId = category ? categoryIdBySlug.get(category) : undefined
    return all.filter(
      (p) =>
        (!divisionId || p.divisionId === divisionId) &&
        (!districtId || p.districtId === districtId) &&
        (!categoryId || p.categoryId === categoryId) &&
        (visitedFilter === 'all' || (visitedFilter === 'yes') === visited.has(p.id)),
    )
  }, [pins.data, division, district, category, visitedFilter, visited, regions, categoryIdBySlug])

  const focus: MapFocus = locate
    ? { kind: 'pin', id: locate.id }
    : district
      ? { kind: 'district', slug: district }
      : division
        ? { kind: 'division', slug: division }
        : { kind: 'country' }

  // A filter change takes the map back to that region.
  useEffect(() => {
    setLocate(null)
  }, [division, district])

  const handleLocate = (id: string) => {
    setSelectedId(id)
    setLocate((prev) => ({ id, nonce: (prev?.nonce ?? 0) + 1 }))
    if (window.matchMedia('(max-width: 1023px)').matches) {
      mapRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  const handleSelectPin = (id: string | null) => {
    setSelectedId(id)
    if (id) document.getElementById(`dest-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
  }

  const districtsForDivision = regions.districts.filter((d) => !division || d.division.slug === division)
  const hasFilters = Boolean(q || division || district || category || visitedFilter !== 'all')

  const renderPopup = (pin: DestinationPin) => {
    const cat = categoryById.get(pin.categoryId)
    const dist = regions.districtById.get(pin.districtId)
    const name = pick(pin.name, pin.nameBn)
    return (
      <div className="flex items-start gap-3">
        <VisitedToggle id={pin.id} name={name} />
        <div className="min-w-0 flex-1">
          <p className="font-semibold leading-snug text-foreground">{name}</p>
          <p className="text-xs text-muted-foreground">
            {dist ? pick(dist.name, dist.nameBn) : ''}
            {cat ? ` · ${pick(cat.name, cat.nameBn)}` : ''}
          </p>
          <Link to={`/destinations/${pin.slug}`} className="mt-1.5 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
            {t('common.details')} <ArrowRight className="size-3" aria-hidden />
          </Link>
        </div>
        <button
          type="button"
          onClick={() => setSelectedId(null)}
          aria-label={t('map.close')}
          className="cursor-pointer rounded-lg p-1 text-muted-foreground hover:bg-muted"
        >
          <X className="size-4" aria-hidden />
        </button>
      </div>
    )
  }

  return (
    <div className="bg-gradient-to-b from-brand-50/60 to-white">
      <ScoreBar />
      <Container className="py-8 sm:py-10">
        <header className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-strong">{t('explore.eyebrow')}</p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-brand-950 sm:text-4xl">{t('explore.title')}</h1>
            <p className="mt-2 max-w-2xl text-muted-foreground">{t('explore.body')}</p>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
          {/* Map column */}
          <div ref={mapRef} className="min-w-0 scroll-mt-20 lg:sticky lg:top-36 lg:self-start">
            <div className="overflow-hidden rounded-2xl border bg-white">
              <div className="flex gap-2 overflow-x-auto border-b bg-muted/40 p-2 [scrollbar-width:none]">
                <RegionTab active={!division} onClick={() => update({ division: null, district: null })}>
                  {t('explore.wholeCountry')}
                </RegionTab>
                {regions.divisions.map((d) => (
                  <RegionTab key={d.slug} active={division === d.slug} onClick={() => update({ division: d.slug, district: null })}>
                    {pick(d.name, d.nameBn)}
                  </RegionTab>
                ))}
              </div>
              <BangladeshMap
                className="h-[62vh] min-h-[380px] rounded-none border-0 lg:h-[calc(100vh-15rem)]"
                pins={mapPins}
                visited={visited}
                focus={focus}
                focusNonce={locate?.nonce ?? 0}
                selectedId={selectedId}
                onSelectPin={handleSelectPin}
                renderPopup={renderPopup}
                highlightDivision={division || undefined}
                highlightDistrict={district || undefined}
                divisionNames={regions.divisionNames}
                districtNames={regions.districtNames}
              />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{t('common.approxNote')}</p>
          </div>

          {/* List column */}
          <section aria-labelledby="list-heading" className="min-w-0 rounded-2xl border bg-white">
            <div className="space-y-4 border-b p-4 sm:p-5">
              <div className="flex items-baseline justify-between gap-3">
                <h2 id="list-heading" className="text-xl font-extrabold text-brand-950">
                  {t('explore.listTitle')}
                </h2>
                {list.data && !skipList && (
                  <span className="text-sm text-muted-foreground">{t('explore.showing', { count: list.data.meta.total })}</span>
                )}
              </div>

              <label className="relative block">
                <span className="sr-only">{t('explore.searchLabel')}</span>
                <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <input
                  type="search"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  placeholder={t('explore.searchPlaceholder')}
                  className="h-12 w-full rounded-full border border-input bg-muted/40 pl-11 pr-4 text-[15px] outline-none transition-colors placeholder:text-muted-foreground focus:border-brand-400 focus:bg-white"
                />
              </label>

              <div className="flex flex-wrap gap-2" role="group" aria-label={t('explore.filterAll')}>
                {(
                  [
                    ['all', t('explore.filterAll')],
                    ['yes', `${t('explore.filterVisited')} (${n(visitedCount)})`],
                    ['no', t('explore.filterNotVisited')],
                  ] as const
                ).map(([value, label]) => (
                  <Chip key={value} active={visitedFilter === value} onClick={() => update({ visited: value === 'all' ? null : value })}>
                    {label}
                  </Chip>
                ))}
              </div>

              <div
                className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0 sm:pb-0 [&>button]:shrink-0"
                role="group"
                aria-label={t('explore.categoryLabel')}
              >
                <Chip active={!category} onClick={() => update({ category: null })}>
                  {t('explore.allCategories')}
                </Chip>
                {(categories.data ?? []).map((c) => (
                  <Chip key={c.slug} active={category === c.slug} onClick={() => update({ category: category === c.slug ? null : c.slug })}>
                    <CategoryIcon name={c.icon} className="size-3.5" />
                    {pick(c.name, c.nameBn)}
                  </Chip>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <SelectField
                  label={t('explore.divisionLabel')}
                  value={division}
                  onChange={(v) => update({ division: v || null, district: null })}
                  options={[{ value: '', label: t('explore.allDivisions') }, ...regions.divisions.map((d) => ({ value: d.slug, label: pick(d.name, d.nameBn) }))]}
                />
                <SelectField
                  label={t('explore.districtLabel')}
                  value={district}
                  onChange={(v) => {
                    const d = regions.districts.find((x) => x.slug === v)
                    update({ district: v || null, division: d ? d.division.slug : division || null })
                  }}
                  options={[{ value: '', label: t('explore.allDistricts') }, ...districtsForDivision.map((d) => ({ value: d.slug, label: pick(d.name, d.nameBn) }))]}
                />
              </div>

              {hasFilters && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchText('')
                    setParams(new URLSearchParams(), { replace: true })
                  }}
                  className="inline-flex cursor-pointer items-center gap-1 text-sm font-semibold text-primary hover:underline"
                >
                  <X className="size-4" aria-hidden /> {t('explore.clearFilters')}
                </button>
              )}
            </div>

            <div className="p-2 sm:p-3">
              {skipList ? (
                <EmptyState className="m-2" title={t('explore.noVisited')} description={t('explore.noVisitedBody')} />
              ) : list.isError ? (
                <ErrorState className="m-2" error={list.error} onRetry={() => void list.refetch()} title={t('explore.listError')} />
              ) : list.isLoading ? (
                <ul className="space-y-2 p-2">
                  {Array.from({ length: 8 }, (_, i) => (
                    <Skeleton key={i} className="h-14" />
                  ))}
                </ul>
              ) : list.data && list.data.items.length === 0 ? (
                <EmptyState
                  className="m-2"
                  title={visitedFilter === 'no' && !q && !category ? t('explore.allVisited') : t('explore.noResults')}
                  description={visitedFilter === 'no' && !q && !category ? undefined : t('explore.noResultsBody')}
                />
              ) : (
                list.data && (
                  <div className={cn('transition-opacity', list.isPlaceholderData && 'opacity-60')}>
                    <ul className="space-y-1">
                      {list.data.items.map((d, i) => (
                        <DestinationListItem
                          key={d.id}
                          destination={d}
                          index={(page - 1) * PAGE_SIZE + i + 1}
                          active={selectedId === d.id}
                          onLocate={handleLocate}
                        />
                      ))}
                    </ul>
                    <div className="px-2 pb-2">
                      <Pagination
                        page={list.data.meta.page}
                        totalPages={list.data.meta.totalPages}
                        onChange={(p) => {
                          update({ page: p > 1 ? String(p) : null }, true)
                          document.getElementById('list-heading')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
                        }}
                      />
                    </div>
                  </div>
                )
              )}
              <p className="px-3 pb-3 pt-2 text-xs leading-relaxed text-muted-foreground">{t('visited.guestNote')}</p>
            </div>
          </section>
        </div>
      </Container>
    </div>
  )
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'inline-flex cursor-pointer items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors',
        active ? 'border-brand-900 bg-brand-900 text-white' : 'border-border bg-white text-foreground hover:border-brand-300 hover:bg-brand-50',
      )}
    >
      {children}
    </button>
  )
}

function RegionTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'shrink-0 cursor-pointer rounded-full border px-4 py-1.5 text-sm font-medium whitespace-nowrap transition-colors',
        active ? 'border-brand-950 bg-brand-950 text-white' : 'bg-white hover:bg-brand-50',
      )}
    >
      {children}
    </button>
  )
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  options: Array<{ value: string; label: string }>
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold text-muted-foreground">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 w-full cursor-pointer rounded-xl border border-input bg-white px-3 text-sm outline-none focus:border-brand-400"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  )
}
