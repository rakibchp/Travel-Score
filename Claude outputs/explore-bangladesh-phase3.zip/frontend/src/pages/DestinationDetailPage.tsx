import { ChevronRight, Info, MapPin } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link, useParams } from 'react-router'
import { EmptyState, ErrorState } from '@/components/common/StateViews'
import { CategoryArt } from '@/components/destination/CategoryArt'
import { DestinationCard } from '@/components/destination/DestinationCard'
import { VisitedToggle } from '@/components/destination/VisitedToggle'
import { Container } from '@/components/layout/Container'
import { BangladeshMap } from '@/components/map/BangladeshMap'
import { buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useDestination } from '@/hooks/useDestinations'
import { useRegions } from '@/hooks/useRegions'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { ApiClientError } from '@/services/apiClient'
import type { DestinationPin } from '@/types/api'

export function DestinationDetailPage() {
  const { slug = '' } = useParams()
  const { t, pick, lang } = useI18n()
  const { visited } = useVisited()
  const regions = useRegions()
  const { data, isLoading, isError, error, refetch } = useDestination(slug)

  if (isLoading) {
    return (
      <Container className="py-10">
        <Skeleton className="h-56 w-full" />
        <Skeleton className="mt-6 h-8 w-2/3" />
        <Skeleton className="mt-3 h-20 w-full" />
      </Container>
    )
  }

  if (isError || !data) {
    const notFound = error instanceof ApiClientError && error.status === 404
    return (
      <Container className="py-16">
        {notFound ? (
          <EmptyState
            title={t('destination.notFound')}
            description={t('destination.notFoundBody')}
            action={
              <Link to="/explore" className={buttonVariants()}>
                {t('nav.explore')}
              </Link>
            }
          />
        ) : (
          <ErrorState error={error} onRetry={() => void refetch()} />
        )}
      </Container>
    )
  }

  const name = pick(data.name, data.nameBn)
  const altName = lang === 'bn' ? data.name : data.nameBn
  const description = pick(data.description ?? '', data.descriptionBn) || pick(data.shortDescription, data.shortDescriptionBn)
  const significance = pick(data.significance ?? '', data.significanceBn)
  const info = data.visitingInfo ?? {}
  const infoRows = (['bestTime', 'openingHours', 'entryFee', 'howToReach', 'tips'] as const).filter((k) => info[k])

  const pin: DestinationPin | null = data.location
    ? {
        id: data.id,
        slug: data.slug,
        name: data.name,
        nameBn: data.nameBn,
        divisionId: data.division.id,
        districtId: data.district.id,
        categoryId: data.category.id,
        coordinates: data.location.coordinates,
      }
    : null

  return (
    <article>
      <div className="relative">
        <CategoryArt category={data.category} image={data.featuredImage} className="h-52 sm:h-64" iconClassName="size-16" />
        <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-black/45 via-black/10 to-transparent" />
        <Container className="absolute inset-x-0 bottom-0 pb-6 text-white">
          <nav aria-label="Breadcrumb" className="mb-2 flex flex-wrap items-center gap-1 text-sm text-white/85">
            <Link to="/explore" className="hover:underline">
              {t('destination.breadcrumbExplore')}
            </Link>
            <ChevronRight className="size-3.5" aria-hidden />
            <Link to={`/divisions/${data.division.slug}`} className="hover:underline">
              {pick(data.division.name, data.division.nameBn)}
            </Link>
            <ChevronRight className="size-3.5" aria-hidden />
            <Link to={`/districts/${data.district.slug}`} className="hover:underline">
              {pick(data.district.name, data.district.nameBn)}
            </Link>
          </nav>
          <h1 className="text-3xl font-extrabold tracking-tight drop-shadow sm:text-5xl">{name}</h1>
          <p className="mt-1 text-white/85">{altName}</p>
        </Container>
      </div>

      <Container className="grid grid-cols-1 gap-8 py-8 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-3">
            <VisitedToggle id={data.id} name={name} variant="pill" />
            <span className="text-sm text-muted-foreground">{t('destination.worth')}</span>
          </div>

          <section className="mt-8">
            <h2 className="text-xl font-bold text-brand-950">{t('destination.about')}</h2>
            <p className="mt-3 text-[16px] leading-relaxed text-foreground/90">{description}</p>
          </section>

          {significance && (
            <section className="mt-8">
              <h2 className="text-xl font-bold text-brand-950">{t('destination.significance')}</h2>
              <p className="mt-3 leading-relaxed text-foreground/90">{significance}</p>
            </section>
          )}

          {infoRows.length > 0 && (
            <section className="mt-8">
              <h2 className="text-xl font-bold text-brand-950">{t('destination.visiting')}</h2>
              <dl className="mt-3 divide-y rounded-2xl border">
                {infoRows.map((k) => (
                  <div key={k} className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]">
                    <dt className="text-sm font-semibold text-muted-foreground">{t(`destination.${k}`)}</dt>
                    <dd className="text-sm">{info[k]}</dd>
                  </div>
                ))}
              </dl>
            </section>
          )}

          <p className="mt-8 flex items-center gap-2 text-xs text-muted-foreground">
            <Info className="size-3.5" aria-hidden /> {t('destination.reportSoon')}
          </p>
        </div>

        <aside className="space-y-4">
          <div className="rounded-2xl border bg-white p-4">
            <h2 className="mb-3 font-bold text-brand-950">{t('destination.location')}</h2>
            <dl className="space-y-2 text-sm">
              {data.upazila && (
                <Row label={t('destination.upazila')}>{pick(data.upazila.name ?? '', data.upazila.nameBn)}</Row>
              )}
              <Row label={t('destination.district')}>
                <Link className="text-primary hover:underline" to={`/districts/${data.district.slug}`}>
                  {pick(data.district.name, data.district.nameBn)}
                </Link>
              </Row>
              <Row label={t('destination.division')}>
                <Link className="text-primary hover:underline" to={`/divisions/${data.division.slug}`}>
                  {pick(data.division.name, data.division.nameBn)}
                </Link>
              </Row>
              <Row label={t('destination.category')}>
                <Link className="text-primary hover:underline" to={`/explore?category=${data.category.slug}`}>
                  {pick(data.category.name, data.category.nameBn)}
                </Link>
              </Row>
            </dl>
            {pin && (
              <BangladeshMap
                className="mt-4 h-64"
                pins={[pin]}
                visited={visited}
                focus={{ kind: 'district', slug: data.district.slug }}
                selectedId={data.id}
                highlightDistrict={data.district.slug}
                divisionNames={regions.divisionNames}
                districtNames={regions.districtNames}
              />
            )}
            <p className="mt-2 text-xs text-muted-foreground">{t('common.approxNote')}</p>
          </div>
          <Link to={`/districts/${data.district.slug}`} className={buttonVariants({ variant: 'outline', className: 'w-full' })}>
            <MapPin aria-hidden /> {t('destination.seeDistrict', { district: pick(data.district.name, data.district.nameBn) })}
          </Link>
        </aside>
      </Container>

      {data.nearby.length > 0 && (
        <Container className="pb-4">
          <h2 className="mb-4 text-xl font-bold text-brand-950">{t('destination.nearby')}</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {data.nearby.map((d) => (
              <DestinationCard
                key={d.id}
                destination={d}
                meta={d.distanceKm !== null ? t('destination.km', { km: d.distanceKm }) : undefined}
              />
            ))}
          </div>
        </Container>
      )}
    </article>
  )
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium">{children}</dd>
    </div>
  )
}
