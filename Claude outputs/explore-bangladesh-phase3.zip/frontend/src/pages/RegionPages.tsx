import { ArrowUpRight, ChevronRight } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { Pagination } from '@/components/common/Pagination'
import { EmptyState, ErrorState } from '@/components/common/StateViews'
import { DestinationListItem } from '@/components/destination/DestinationListItem'
import { DivisionGrid } from '@/components/home/DivisionGrid'
import { Container } from '@/components/layout/Container'
import { BangladeshMap } from '@/components/map/BangladeshMap'
import { buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useDestinationList, useDistrict, useDivision, usePins } from '@/hooks/useDestinations'
import { useRegions } from '@/hooks/useRegions'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { ApiClientError } from '@/services/apiClient'

function ProgressBar({ value, total }: { value: number; total: number }) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0
  return (
    <div className="h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
      <div className="h-full rounded-full bg-gradient-to-r from-brand-600 to-brand-400 transition-[width] duration-500" style={{ width: `${pct}%` }} />
    </div>
  )
}

/** Count visited pins per district id (guest list, validated against existing pins). */
function useVisitedByDistrict() {
  const pins = usePins()
  const { visited } = useVisited()
  return useMemo(() => {
    const m = new Map<string, number>()
    for (const p of pins.data ?? []) if (visited.has(p.id)) m.set(p.districtId, (m.get(p.districtId) ?? 0) + 1)
    return { byDistrict: m, pins: pins.data ?? [] }
  }, [pins.data, visited])
}

function PageHeader({ eyebrow, title, body, crumbs }: { eyebrow: string; title: string; body?: string; crumbs?: Array<{ to: string; label: string }> }) {
  return (
    <header className="mb-6">
      {crumbs && (
        <nav aria-label="Breadcrumb" className="mb-3 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          {crumbs.map((c, i) => (
            <span key={c.to} className="flex items-center gap-1">
              {i > 0 && <ChevronRight className="size-3.5" aria-hidden />}
              <Link to={c.to} className="hover:text-primary hover:underline">
                {c.label}
              </Link>
            </span>
          ))}
        </nav>
      )}
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-strong">{eyebrow}</p>
      <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-brand-950 sm:text-4xl">{title}</h1>
      {body && <p className="mt-2 max-w-2xl text-muted-foreground">{body}</p>}
    </header>
  )
}

/* ------------------------------------------------------------------ */

export function DivisionsPage() {
  const { t } = useI18n()
  const navigate = useNavigate()
  const regions = useRegions()
  const { visited } = useVisited()
  const { pins } = useVisitedByDistrict()

  return (
    <>
      <Container className="py-8 sm:py-10">
        <PageHeader eyebrow={t('divisions.eyebrow')} title={t('divisions.title')} body={t('divisions.body')} />
        <BangladeshMap
          className="h-[70vh] min-h-[420px]"
          pins={pins}
          visited={visited}
          divisionNames={regions.divisionNames}
          districtNames={regions.districtNames}
          onRegionClick={(_, slug) => navigate(`/districts/${slug}`)}
          onSelectPin={(id) => {
            const p = pins.find((x) => x.id === id)
            if (p) navigate(`/destinations/${p.slug}`)
          }}
        />
        <p className="mt-2 text-xs text-muted-foreground">{t('common.approxNote')}</p>
      </Container>
      <DivisionGrid />
    </>
  )
}

/* ------------------------------------------------------------------ */

export function DivisionPage() {
  const { slug = '' } = useParams()
  const { t, n, pick } = useI18n()
  const navigate = useNavigate()
  const regions = useRegions()
  const { visited } = useVisited()
  const { byDistrict, pins } = useVisitedByDistrict()
  const division = useDivision(slug)

  if (division.isLoading) return <LoadingPage />
  if (division.isError || !division.data) {
    return <RegionError error={division.error} onRetry={() => void division.refetch()} notFoundTitle={t('divisions.divisionNotFound')} />
  }

  const d = division.data
  const name = pick(d.name, d.nameBn)
  const divisionPins = pins.filter((p) => p.divisionId === d.id)
  const visitedHere = divisionPins.filter((p) => visited.has(p.id)).length

  return (
    <Container className="py-8 sm:py-10">
      <PageHeader
        eyebrow={t('divisions.divisionLabel', { name })}
        title={name}
        crumbs={[{ to: '/divisions', label: t('nav.divisions') }]}
      />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div>
          <BangladeshMap
            className="h-[60vh] min-h-[380px]"
            pins={divisionPins}
            visited={visited}
            focus={{ kind: 'division', slug: d.slug }}
            highlightDivision={d.slug}
            divisionNames={regions.divisionNames}
            districtNames={regions.districtNames}
            onRegionClick={(_, districtSlug) => navigate(`/districts/${districtSlug}`)}
            onSelectPin={(id) => {
              const p = divisionPins.find((x) => x.id === id)
              if (p) navigate(`/destinations/${p.slug}`)
            }}
          />
          <div className="mt-4 rounded-2xl border bg-white p-4">
            <div className="mb-2 flex justify-between text-sm font-semibold">
              <span>{t('home.progressLabel')}</span>
              <span className="text-brand-800">{t('divisions.completion', { visited: visitedHere, total: d.destinationCount })}</span>
            </div>
            <ProgressBar value={visitedHere} total={d.destinationCount} />
          </div>
        </div>

        <section aria-labelledby="districts-heading">
          <h2 id="districts-heading" className="mb-3 text-xl font-bold text-brand-950">
            {t('divisions.districtsIn', { name })}
          </h2>
          <ul className="grid gap-3 sm:grid-cols-2">
            {d.districts.map((district) => {
              const v = byDistrict.get(district.id) ?? 0
              return (
                <li key={district.id}>
                  <Link
                    to={`/districts/${district.slug}`}
                    className="group flex h-full flex-col gap-3 rounded-2xl border bg-white p-4 transition-colors hover:border-brand-300 hover:bg-brand-50/50"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-bold text-brand-950">{pick(district.name, district.nameBn)}</p>
                        <p className="text-xs text-muted-foreground">{t('common.destinations', { count: district.destinationCount })}</p>
                      </div>
                      <ArrowUpRight className="size-4 text-muted-foreground group-hover:text-primary" aria-hidden />
                    </div>
                    <ProgressBar value={v} total={district.destinationCount} />
                    <p className="text-xs font-medium text-brand-700">
                      {n(v)}/{n(district.destinationCount)}
                    </p>
                  </Link>
                </li>
              )
            })}
          </ul>
        </section>
      </div>
    </Container>
  )
}

/* ------------------------------------------------------------------ */

const DISTRICT_PAGE_SIZE = 30

export function DistrictPage() {
  const { slug = '' } = useParams()
  const { t, pick } = useI18n()
  const navigate = useNavigate()
  const regions = useRegions()
  const { visited } = useVisited()
  const { byDistrict, pins } = useVisitedByDistrict()
  const district = useDistrict(slug)
  const [page, setPage] = useState(1)
  const list = useDestinationList({ district: slug, sort: 'name', page, limit: DISTRICT_PAGE_SIZE }, Boolean(district.data))

  if (district.isLoading) return <LoadingPage />
  if (district.isError || !district.data) {
    return <RegionError error={district.error} onRetry={() => void district.refetch()} notFoundTitle={t('divisions.districtNotFound')} />
  }

  const d = district.data
  const name = pick(d.name, d.nameBn)
  const districtPins = pins.filter((p) => p.districtId === d.id)
  const visitedHere = byDistrict.get(d.id) ?? 0

  return (
    <Container className="py-8 sm:py-10">
      <PageHeader
        eyebrow={t('divisions.districtLabel', { name })}
        title={name}
        crumbs={[
          { to: '/divisions', label: t('nav.divisions') },
          { to: `/divisions/${d.division.slug}`, label: pick(d.division.name, d.division.nameBn) },
        ]}
      />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div>
          <BangladeshMap
            className="h-[55vh] min-h-[360px]"
            pins={districtPins}
            visited={visited}
            focus={{ kind: 'district', slug: d.slug }}
            highlightDistrict={d.slug}
            divisionNames={regions.divisionNames}
            districtNames={regions.districtNames}
            onSelectPin={(id) => {
              const p = districtPins.find((x) => x.id === id)
              if (p) navigate(`/destinations/${p.slug}`)
            }}
          />
          <div className="mt-4 rounded-2xl border bg-white p-4">
            <div className="mb-2 flex justify-between text-sm font-semibold">
              <span>{t('home.progressLabel')}</span>
              <span className="text-brand-800">{t('divisions.completion', { visited: visitedHere, total: d.destinationCount })}</span>
            </div>
            <ProgressBar value={visitedHere} total={d.destinationCount} />
          </div>
        </div>

        <section aria-labelledby="dest-heading" className="rounded-2xl border bg-white p-2 sm:p-3">
          <h2 id="dest-heading" className="px-2 pb-2 pt-1 text-xl font-bold text-brand-950">
            {t('divisions.destinationsIn', { name })}
          </h2>
          {list.isError ? (
            <ErrorState error={list.error} onRetry={() => void list.refetch()} />
          ) : list.isLoading || !list.data ? (
            <div className="space-y-2 p-2">
              {Array.from({ length: 4 }, (_, i) => (
                <Skeleton key={i} className="h-14" />
              ))}
            </div>
          ) : list.data.items.length === 0 ? (
            <EmptyState title={t('divisions.noDestinations')} />
          ) : (
            <>
              <ul className="space-y-1">
                {list.data.items.map((item) => (
                  <DestinationListItem key={item.id} destination={item} />
                ))}
              </ul>
              <Pagination page={list.data.meta.page} totalPages={list.data.meta.totalPages} onChange={setPage} />
            </>
          )}
        </section>
      </div>
    </Container>
  )
}

/* ------------------------------------------------------------------ */

function LoadingPage() {
  return (
    <Container className="py-10">
      <Skeleton className="h-8 w-48" />
      <Skeleton className="mt-3 h-10 w-72" />
      <Skeleton className="mt-6 h-[50vh] w-full" />
    </Container>
  )
}

function RegionError({ error, onRetry, notFoundTitle }: { error: unknown; onRetry: () => void; notFoundTitle: string }) {
  const { t } = useI18n()
  const notFound = error instanceof ApiClientError && error.status === 404
  return (
    <Container className="py-16">
      {notFound ? (
        <EmptyState
          title={notFoundTitle}
          action={
            <Link to="/divisions" className={buttonVariants()}>
              {t('nav.divisions')}
            </Link>
          }
        />
      ) : (
        <ErrorState error={error} onRetry={onRetry} />
      )}
    </Container>
  )
}
