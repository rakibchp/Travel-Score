import { Compass, MapPinned, RotateCcw, Share2, UserPlus } from 'lucide-react'
import { useState, type ReactNode } from 'react'
import { Link } from 'react-router'
import { CategoryIcon } from '@/components/common/CategoryIcon'
import { EmptyState, ErrorState } from '@/components/common/StateViews'
import { DestinationCard } from '@/components/destination/DestinationCard'
import { Container } from '@/components/layout/Container'
import { ScoreBar } from '@/components/score/ScoreBar'
import { Button, buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useScorecard } from '@/hooks/useScorecard'
import { useI18n } from '@/i18n/useI18n'
import { visitedStore } from '@/lib/visitedStore'
import { cn } from '@/lib/utils'
import type { Scorecard, ScoreBucket } from '@/types/api'

export function ScorecardPage() {
  const { t } = useI18n()
  const { data, isLoading, isError, error, refetch } = useScorecard()

  return (
    <>
      <ScoreBar showLink={false} />
      <div className="bg-gradient-to-b from-brand-50/60 to-white">
        <Container className="py-8 sm:py-10">
          <header className="mb-6">
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-strong">{t('score.eyebrow')}</p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-brand-950 sm:text-4xl">{t('score.title')}</h1>
            <p className="mt-2 max-w-2xl text-muted-foreground">{t('score.body')}</p>
          </header>

          {isError && !data ? (
            <ErrorState error={error} onRetry={() => void refetch()} title={t('score.error')} />
          ) : isLoading || !data ? (
            <div className="grid gap-4 lg:grid-cols-3">
              <Skeleton className="h-64 lg:col-span-1" />
              <Skeleton className="h-64 lg:col-span-2" />
            </div>
          ) : (
            <ScorecardContent data={data} />
          )}
        </Container>
      </div>
    </>
  )
}

function ScorecardContent({ data }: { data: Scorecard }) {
  const { t, n } = useI18n()

  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-3">
        <ScoreHero data={data} />
        <div className="grid grid-cols-3 gap-3 lg:col-span-2 lg:grid-cols-3 lg:content-start">
          <MiniStat label={t('score.districts')} value={data.districtsExplored} total={data.totalDistricts} />
          <MiniStat label={t('score.divisions')} value={data.divisionsExplored} total={data.totalDivisions} />
          <MiniStat label={t('score.categories')} value={data.categoriesExplored} total={data.totalCategories} />
          <div className="col-span-3 rounded-2xl border bg-white p-4 sm:p-5">
            <h2 className="mb-3 font-bold text-brand-950">{t('score.byDivision')}</h2>
            <BucketBars rows={data.byDivision} link={(r) => `/divisions/${r.slug}`} />
          </div>
        </div>
      </div>

      {data.score === 0 && (
        <EmptyState
          icon={<Compass aria-hidden />}
          title={t('score.startTitle')}
          description={t('score.startBody')}
          action={
            <Link to="/explore" className={buttonVariants()}>
              <Compass aria-hidden /> {t('home.startExploring')}
            </Link>
          }
        />
      )}

      <section aria-labelledby="where-next" className="rounded-2xl border bg-white p-4 sm:p-5">
        <h2 id="where-next" className="text-xl font-bold text-brand-950">
          {t('score.whereNext')}
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">{t('score.whereNextBody')}</p>
        {data.suggestions.length === 0 ? (
          <p className="mt-4 text-sm font-semibold text-brand-800">{t('score.noSuggestions')}</p>
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {data.suggestions.map((d) => (
              <DestinationCard key={d.id} destination={d} />
            ))}
          </div>
        )}
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section aria-labelledby="district-map" className="rounded-2xl border bg-white p-4 sm:p-5">
          <h2 id="district-map" className="font-bold text-brand-950">
            {t('score.districtMap')}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">{t('score.districtMapBody')}</p>
          <DistrictTiles data={data} />
        </section>
        <section aria-labelledby="by-category" className="rounded-2xl border bg-white p-4 sm:p-5">
          <h2 id="by-category" className="mb-3 font-bold text-brand-950">
            {t('score.byCategory')}
          </h2>
          <BucketBars
            rows={data.byCategory}
            link={(r) => `/explore?category=${r.slug}`}
            icon={(r) => <CategoryIcon name={(r as ScoreBucket & { icon: string | null }).icon} className="size-4 text-brand-700" />}
          />
        </section>
      </div>

      <div className="flex flex-col gap-4 rounded-2xl border bg-white p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
        <div className="space-y-1 text-sm text-muted-foreground">
          <p className="flex items-center gap-2">
            <Share2 className="size-4 text-brand-700" aria-hidden /> {t('score.shareSoon')}
          </p>
          <p>{t('visited.guestNote')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/register" className={buttonVariants({ variant: 'secondary' })}>
            <UserPlus aria-hidden /> {t('score.saveCta')}
          </Link>
          {data.score > 0 && <ResetButton />}
        </div>
      </div>
      <p className="sr-only">{n(data.score)}</p>
    </div>
  )
}

function ScoreHero({ data }: { data: Scorecard }) {
  const { t, n } = useI18n()
  const r = 52
  const c = 2 * Math.PI * r
  const dash = (Math.min(data.percentage, 100) / 100) * c

  return (
    <div className="relative overflow-hidden rounded-2xl bg-brand-800 p-6 text-white">
      <div aria-hidden className="absolute -bottom-16 -right-12 size-48 rounded-full bg-flag-red/90" />
      <div className="relative flex items-center gap-5">
        <svg viewBox="0 0 120 120" className="size-32 shrink-0 -rotate-90" aria-hidden>
          <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,.15)" strokeWidth="12" />
          <circle
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke="#fff"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={`${dash} ${c}`}
            className="transition-[stroke-dasharray] duration-700"
          />
        </svg>
        <div>
          <p className="text-5xl font-extrabold tabular-nums">{n(data.score)}</p>
          <p className="text-brand-100">
            {t('score.points')} {t('score.outOf', { total: data.totalDestinations })}
          </p>
        </div>
      </div>
      <p className="relative mt-5 text-lg font-semibold">{t('score.explored', { pct: n(data.percentage) })}</p>
    </div>
  )
}

function MiniStat({ label, value, total }: { label: string; value: number; total: number }) {
  const { n } = useI18n()
  return (
    <div className="rounded-2xl border bg-white p-4">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-extrabold text-brand-950">
        {n(value)}
        <span className="text-base font-semibold text-muted-foreground">/{n(total)}</span>
      </p>
    </div>
  )
}

function BucketBars({ rows, link, icon }: { rows: ScoreBucket[]; link: (r: ScoreBucket) => string; icon?: (r: ScoreBucket) => ReactNode }) {
  const { n, pick } = useI18n()
  return (
    <ul className="space-y-2.5">
      {rows
        .filter((r) => r.total > 0)
        .map((r) => {
          const pct = r.total ? (r.visited / r.total) * 100 : 0
          return (
            <li key={r.id}>
              <Link to={link(r)} className="group grid grid-cols-[minmax(0,9rem)_1fr_auto] items-center gap-3 text-sm">
                <span className="flex min-w-0 items-center gap-2 truncate font-medium group-hover:text-primary">
                  {icon?.(r)}
                  <span className="truncate">{pick(r.name, r.nameBn)}</span>
                </span>
                <span className="h-2 overflow-hidden rounded-full bg-muted">
                  <span className="block h-full rounded-full bg-primary transition-[width] duration-500" style={{ width: `${pct}%` }} />
                </span>
                <span className="w-14 text-right tabular-nums text-muted-foreground">
                  {n(r.visited)}/{n(r.total)}
                </span>
              </Link>
            </li>
          )
        })}
    </ul>
  )
}

function DistrictTiles({ data }: { data: Scorecard }) {
  const { t, pick } = useI18n()
  return (
    <>
      <div className="mt-4 space-y-3">
        {data.byDivision.map((div) => (
          <div key={div.id}>
            <p className="mb-1.5 text-xs font-semibold text-muted-foreground">{pick(div.name, div.nameBn)}</p>
            <ul className="flex flex-wrap gap-1.5">
              {data.byDistrict
                .filter((d) => d.divisionId === div.id)
                .map((d) => {
                  const ratio = d.total ? d.visited / d.total : 0
                  const label = t('score.districtTile', { name: pick(d.name, d.nameBn), visited: d.visited, total: d.total })
                  return (
                    <li key={d.id}>
                      <Link
                        to={`/districts/${d.slug}`}
                        title={label}
                        aria-label={label}
                        className={cn(
                          'flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-[11px] font-semibold transition-transform hover:scale-105',
                          ratio === 0 && 'bg-muted text-muted-foreground',
                          ratio > 0 && ratio < 0.5 && 'bg-brand-200 text-brand-900',
                          ratio >= 0.5 && ratio < 1 && 'bg-brand-500 text-white',
                          ratio === 1 && 'bg-brand-800 text-white',
                        )}
                      >
                        {pick(d.name, d.nameBn)}
                      </Link>
                    </li>
                  )
                })}
            </ul>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
        <MapPinned className="size-3.5" aria-hidden />
        <Legend className="bg-muted" label={t('score.legendNone')} />
        <Legend className="bg-brand-200" label={t('score.legendSome')} />
        <Legend className="bg-brand-500" label="½+" />
        <Legend className="bg-brand-800" label={t('score.legendAll')} />
      </div>
    </>
  )
}

function Legend({ className, label }: { className: string; label: string }) {
  return (
    <span className="flex items-center gap-1">
      <span className={cn('size-3 rounded', className)} aria-hidden /> {label}
    </span>
  )
}

function ResetButton() {
  const { t } = useI18n()
  const [confirming, setConfirming] = useState(false)
  if (!confirming) {
    return (
      <Button variant="outline" onClick={() => setConfirming(true)}>
        <RotateCcw aria-hidden /> {t('score.reset')}
      </Button>
    )
  }
  return (
    <div role="alertdialog" aria-label={t('score.resetConfirm')} className="flex flex-wrap items-center gap-2 rounded-2xl bg-red-50 p-2 pl-3">
      <span className="text-sm font-medium text-accent-strong">{t('score.resetConfirm')}</span>
      <Button
        variant="accent"
        size="sm"
        onClick={() => {
          visitedStore.clear()
          setConfirming(false)
        }}
      >
        {t('score.resetYes')}
      </Button>
      <Button variant="ghost" size="sm" onClick={() => setConfirming(false)} autoFocus>
        {t('score.resetNo')}
      </Button>
    </div>
  )
}
