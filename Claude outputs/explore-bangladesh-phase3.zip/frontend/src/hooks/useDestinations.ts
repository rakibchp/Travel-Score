import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { destinationApi, type DestinationFilters } from '@/services/destinationApi'

export const destinationKeys = {
  list: (filters: DestinationFilters) => ['destinations', 'list', filters] as const,
  pins: ['destinations', 'pins'] as const,
  featured: (limit: number) => ['destinations', 'featured', limit] as const,
  popular: (limit: number) => ['destinations', 'popular', limit] as const,
  detail: (slug: string) => ['destinations', 'detail', slug] as const,
  division: (slug: string) => ['divisions', 'detail', slug] as const,
  district: (slug: string) => ['districts', 'detail', slug] as const,
}

export function useDestinationList(filters: DestinationFilters, enabled = true) {
  return useQuery({
    queryKey: destinationKeys.list(filters),
    queryFn: () => destinationApi.list(filters),
    placeholderData: keepPreviousData, // keep the old page visible while the next loads
    staleTime: 60_000,
    enabled,
  })
}

export function usePins() {
  return useQuery({ queryKey: destinationKeys.pins, queryFn: destinationApi.pins, staleTime: 5 * 60_000 })
}

export function useFeatured(limit = 8) {
  return useQuery({ queryKey: destinationKeys.featured(limit), queryFn: () => destinationApi.featured(limit), staleTime: 5 * 60_000 })
}

export function usePopular(limit = 8) {
  return useQuery({ queryKey: destinationKeys.popular(limit), queryFn: () => destinationApi.popular(limit), staleTime: 5 * 60_000 })
}

export function useDestination(slug: string) {
  return useQuery({ queryKey: destinationKeys.detail(slug), queryFn: () => destinationApi.detail(slug), staleTime: 5 * 60_000 })
}

export function useDivision(slug: string) {
  return useQuery({ queryKey: destinationKeys.division(slug), queryFn: () => destinationApi.division(slug), staleTime: 10 * 60_000 })
}

export function useDistrict(slug: string) {
  return useQuery({ queryKey: destinationKeys.district(slug), queryFn: () => destinationApi.district(slug), staleTime: 10 * 60_000 })
}
