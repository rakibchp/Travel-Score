import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { useEffect, useMemo } from 'react'
import { useVisited, visitedStore } from '@/lib/visitedStore'
import { scoreApi } from '@/services/scoreApi'

/**
 * The current visitor's scorecard, calculated by the server.
 *
 * Guests: the ids ticked in this browser are sent to POST /score/preview.
 * (Phase 4 adds a branch for signed-in users that reads GET /me/score.)
 * While a new result is loading, the previous one stays on screen.
 */
export function useScorecard() {
  const { visited } = useVisited()
  const ids = useMemo(() => [...visited].sort(), [visited])

  const query = useQuery({
    queryKey: ['score', 'guest', ids],
    queryFn: () => scoreApi.preview(ids),
    placeholderData: keepPreviousData,
    staleTime: 60_000,
  })

  // Drop ticks the server didn't count (destination removed or deactivated).
  const ignored = query.data?.ignoredIds
  useEffect(() => {
    if (ignored && ignored.length) visitedStore.removeMany(ignored)
  }, [ignored])

  return query
}
