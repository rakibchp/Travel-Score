import { useMemo } from 'react'
import type { RegionName } from '@/components/map/BangladeshMap'
import { useDistricts, useDivisions } from '@/hooks/useReferenceData'

/** Division/district lookups shared by the map, filters and pin filtering. */
export function useRegions() {
  const divisions = useDivisions()
  const districts = useDistricts()

  return useMemo(() => {
    const divisionList = divisions.data ?? []
    const districtList = districts.data ?? []
    const divisionNames: RegionName[] = divisionList.map((d) => ({ slug: d.slug, name: d.name, nameBn: d.nameBn }))
    const districtNames: RegionName[] = districtList.map((d) => ({
      slug: d.slug,
      name: d.name,
      nameBn: d.nameBn,
      divisionSlug: d.division.slug,
    }))
    return {
      divisions: divisionList,
      districts: districtList,
      divisionNames,
      districtNames,
      divisionIdBySlug: new Map(divisionList.map((d) => [d.slug, d.id])),
      districtIdBySlug: new Map(districtList.map((d) => [d.slug, d.id])),
      districtById: new Map(districtList.map((d) => [d.id, d])),
      isLoading: divisions.isLoading || districts.isLoading,
    }
  }, [divisions.data, districts.data, divisions.isLoading, districts.isLoading])
}
