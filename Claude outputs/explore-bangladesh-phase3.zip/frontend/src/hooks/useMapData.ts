import { useQuery } from '@tanstack/react-query'
import type { MapData } from '@/lib/mapProjection'

/** The boundary file (~160 KB, ~50 KB gzipped) is code-split and only loaded on map pages. */
export function useMapData() {
  return useQuery({
    queryKey: ['map-data'],
    queryFn: async () => (await import('@/data/bangladesh-map.json')).default as unknown as MapData,
    staleTime: Infinity,
    gcTime: Infinity,
  })
}
