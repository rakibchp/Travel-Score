import { createContext, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { bn, type Dictionary } from './bn'
import { en } from './en'

export type Lang = 'bn' | 'en'

const STORAGE_KEY = 'eb.lang'
const dictionaries: Record<Lang, Dictionary> = { bn, en }

type Vars = Record<string, string | number>

type DotPaths<T, P extends string = ''> = {
  [K in keyof T & string]: T[K] extends string ? `${P}${K}` : DotPaths<T[K], `${P}${K}.`>
}[keyof T & string]

export type TranslationKey = DotPaths<Dictionary>

export type I18nValue = {
  lang: Lang
  setLang: (lang: Lang) => void
  /** Translate a key, filling {placeholders}; numbers are formatted in the active language. */
  t: (key: TranslationKey, vars?: Vars) => string
  /** Format a number with Bangla or Latin digits. */
  n: (value: number, options?: Intl.NumberFormatOptions) => string
  /** Pick the right language variant of database content, falling back to English. */
  pick: (english: string, bangla?: string | null) => string
}

// eslint-disable-next-line react-refresh/only-export-components
export const I18nContext = createContext<I18nValue | null>(null)

function readStoredLang(): Lang {
  try {
    const v = localStorage.getItem(STORAGE_KEY)
    return v === 'en' || v === 'bn' ? v : 'bn'
  } catch {
    return 'bn'
  }
}

function lookup(dict: Dictionary, key: string): string {
  let node: unknown = dict
  for (const part of key.split('.')) {
    node = (node as Record<string, unknown> | undefined)?.[part]
  }
  return typeof node === 'string' ? node : key
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(readStoredLang)

  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])

  const setLang = useCallback((next: Lang) => {
    setLangState(next)
    try {
      localStorage.setItem(STORAGE_KEY, next)
    } catch {
      // Private mode / storage disabled: the choice just won't persist.
    }
  }, [])

  const value = useMemo<I18nValue>(() => {
    const numberFormat = new Intl.NumberFormat(lang === 'bn' ? 'bn-BD' : 'en-US')
    const n = (v: number, options?: Intl.NumberFormatOptions) =>
      options ? new Intl.NumberFormat(lang === 'bn' ? 'bn-BD' : 'en-US', options).format(v) : numberFormat.format(v)
    const dict = dictionaries[lang]
    return {
      lang,
      setLang,
      n,
      t: (key, vars) => {
        const template = lookup(dict, key)
        if (!vars) return template
        return template.replace(/\{(\w+)\}/g, (_, name: string) => {
          const v = vars[name]
          if (v === undefined) return `{${name}}`
          return typeof v === 'number' ? n(v) : v
        })
      },
      pick: (english, bangla) => (lang === 'bn' && bangla ? bangla : english),
    }
  }, [lang, setLang])

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}
