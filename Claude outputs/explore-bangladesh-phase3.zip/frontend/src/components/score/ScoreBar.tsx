import { ArrowRight, Trophy } from 'lucide-react'
import { Link } from 'react-router'
import { Container } from '@/components/layout/Container'
import { useScorecard } from '@/hooks/useScorecard'
import { useI18n } from '@/i18n/useI18n'
import { cn } from '@/lib/utils'

/**
 * Sticky progress strip shown under the header on Explore and Scorecard
 * (the pattern Jaio uses). Everything shown comes from the server scorecard.
 */
export function ScoreBar({ showLink = true }: { showLink?: boolean }) {
  const { t, n } = useI18n()
  const { data, isFetching } = useScorecard()

  const score = data?.score ?? 0
  const total = data?.totalDestinations ?? 0
  const pct = data?.percentage ?? 0

  return (
    <div className="sticky top-16 z-30 border-b bg-white/95 backdrop-blur-md">
      <Container className="flex items-center gap-4 py-2.5 sm:gap-6">
        <div className="flex shrink-0 items-baseline gap-1.5" aria-live="polite">
          <Trophy className="size-5 self-center text-accent-strong" aria-hidden />
          <span className="text-2xl font-extrabold tabular-nums text-primary sm:text-3xl">{n(score)}</span>
          <span className="text-sm text-muted-foreground">{t('score.outOf', { total })}</span>
        </div>

        <div className="min-w-0 flex-1">
          <div
            className="h-2.5 overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-label={t('home.progressLabel')}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={pct}
          >
            <div
              className={cn('h-full rounded-full bg-gradient-to-r from-brand-600 to-brand-400 transition-[width] duration-500', isFetching && 'opacity-70')}
              style={{ width: `${Math.max(pct, score > 0 ? 1.5 : 0)}%` }}
            />
          </div>
          <div className="mt-1 flex flex-wrap gap-x-4 text-xs text-muted-foreground">
            <span className="font-semibold text-brand-800">{t('score.barExplored', { pct: n(pct) })}</span>
            <span>
              {t('score.districts')} {t('score.ofTotal', { value: data?.districtsExplored ?? 0, total: data?.totalDistricts ?? 64 })}
            </span>
            <span className="hidden sm:inline">
              {t('score.divisions')} {t('score.ofTotal', { value: data?.divisionsExplored ?? 0, total: data?.totalDivisions ?? 8 })}
            </span>
          </div>
        </div>

        {showLink && (
          <Link
            to="/scorecard"
            className="hidden shrink-0 items-center gap-1 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-brand-800 sm:inline-flex"
          >
            {t('score.seeScorecard')} <ArrowRight className="size-4" aria-hidden />
          </Link>
        )}
      </Container>
    </div>
  )
}
