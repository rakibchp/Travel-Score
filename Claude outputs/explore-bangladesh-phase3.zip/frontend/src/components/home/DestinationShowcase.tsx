import { ArrowRight, Sparkles, TrendingUp } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import { SectionHeading } from '@/components/common/SectionHeading'
import { EmptyState, ErrorState } from '@/components/common/StateViews'
import { DestinationCard } from '@/components/destination/DestinationCard'
import { Container } from '@/components/layout/Container'
import { buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useFeatured, usePopular } from '@/hooks/useDestinations'
import { useI18n } from '@/i18n/useI18n'
import type { DestinationCard as Destination } from '@/types/api'

function Shelf({
  id,
  eyebrow,
  title,
  icon,
  query,
}: {
  id: string
  eyebrow: string
  title: string
  icon: ReactNode
  query: { data?: Destination[]; isLoading: boolean; isError: boolean; error: unknown; refetch: () => unknown }
}) {
  const { t } = useI18n()
  return (
    <section aria-labelledby={id} className="py-10">
      <Container>
        <SectionHeading
          id={id}
          eyebrow={eyebrow}
          title={title}
          action={
            <Link to="/explore" className={buttonVariants({ variant: 'ghost', size: 'sm' })}>
              {t('common.viewAll')} <ArrowRight aria-hidden />
            </Link>
          }
        />
        {query.isError ? (
          <ErrorState error={query.error} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }, (_, i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        ) : !query.data || query.data.length === 0 ? (
          <EmptyState icon={icon} title={t('home.showcaseEmpty')} description={t('home.showcaseEmptyBody')} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {query.data.map((d) => (
              <DestinationCard key={d.id} destination={d} />
            ))}
          </div>
        )}
      </Container>
    </section>
  )
}

export function FeaturedDestinations() {
  const { t } = useI18n()
  return <Shelf id="featured-heading" eyebrow={t('home.featuredEyebrow')} title={t('home.featuredTitle')} icon={<Sparkles aria-hidden />} query={useFeatured(8)} />
}

export function PopularDestinations() {
  const { t } = useI18n()
  return <Shelf id="popular-heading" eyebrow={t('home.popularEyebrow')} title={t('home.popularTitle')} icon={<TrendingUp aria-hidden />} query={usePopular(4)} />
}
