import { Check } from 'lucide-react'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { cn } from '@/lib/utils'

type Props = { id: string; name: string; variant?: 'box' | 'pill'; className?: string }

/** Tick box for marking a destination visited. Guests: saved in this browser. */
export function VisitedToggle({ id, name, variant = 'box', className }: Props) {
  const { t } = useI18n()
  const { visited, toggle } = useVisited()
  const on = visited.has(id)
  const label = on ? t('visited.unmarkAria', { name }) : t('visited.markAria', { name })

  if (variant === 'pill') {
    return (
      <button
        type="button"
        role="checkbox"
        aria-checked={on}
        aria-label={label}
        onClick={() => toggle(id)}
        className={cn(
          'inline-flex h-11 cursor-pointer items-center gap-2 rounded-full border px-5 text-sm font-semibold transition-colors',
          on ? 'border-primary bg-primary text-white hover:bg-brand-800' : 'border-input bg-white text-foreground hover:bg-brand-50',
          className,
        )}
      >
        <span
          className={cn(
            'flex size-5 items-center justify-center rounded-md border-2',
            on ? 'border-white bg-white text-primary' : 'border-brand-600',
          )}
          aria-hidden
        >
          {on && <Check className="size-3.5" strokeWidth={3} />}
        </span>
        {on ? t('visited.visited') : t('visited.markVisited')}
      </button>
    )
  }

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={on}
      aria-label={label}
      title={on ? t('visited.visited') : t('visited.notVisited')}
      onClick={(e) => {
        e.preventDefault()
        e.stopPropagation()
        toggle(id)
      }}
      className={cn(
        'flex size-7 shrink-0 cursor-pointer items-center justify-center rounded-lg border-2 transition-all active:scale-90',
        on ? 'border-primary bg-primary text-white' : 'border-brand-300 bg-white hover:border-primary',
        className,
      )}
    >
      {on && <Check className="size-4" strokeWidth={3} aria-hidden />}
    </button>
  )
}
