import { LocateFixed } from 'lucide-react'
import { Link } from 'react-router'
import { VisitedToggle } from '@/components/destination/VisitedToggle'
import { useI18n } from '@/i18n/useI18n'
import { useVisited } from '@/lib/visitedStore'
import { cn } from '@/lib/utils'
import type { DestinationCard } from '@/types/api'

type Props = {
  destination: DestinationCard
  index?: number
  active?: boolean
  onLocate?: (id: string) => void
}

/** A row in the explorer list: tick box, name, place · type, and "show on map". */
export function DestinationListItem({ destination, index, active, onLocate }: Props) {
  const { t, n, pick } = useI18n()
  const { visited } = useVisited()
  const on = visited.has(destination.id)
  const name = pick(destination.name, destination.nameBn)
  const place = [
    destination.upazila ? pick(destination.upazila.name ?? '', destination.upazila.nameBn) : null,
    pick(destination.district.name, destination.district.nameBn),
  ]
    .filter(Boolean)
    .join(', ')

  return (
    <li
      id={`dest-${destination.id}`}
      className={cn(
        'flex items-center gap-3 rounded-2xl px-3 py-3 transition-colors sm:px-4',
        on ? 'bg-brand-50/80' : 'hover:bg-muted/60',
        active && 'ring-2 ring-brand-400',
      )}
    >
      <VisitedToggle id={destination.id} name={name} />
      <div className="min-w-0 flex-1">
        <Link to={`/destinations/${destination.slug}`} className="block font-semibold leading-snug text-foreground hover:text-primary">
          {index !== undefined && <span className="text-muted-foreground">{n(index)}. </span>}
          {name}
        </Link>
        <p className="truncate text-xs text-muted-foreground">
          {place} · {pick(destination.category.name, destination.category.nameBn)}
        </p>
      </div>
      {onLocate && destination.location && (
        <button
          type="button"
          onClick={() => onLocate(destination.id)}
          aria-label={`${t('explore.locate')}: ${name}`}
          title={t('explore.locate')}
          className="flex size-9 shrink-0 cursor-pointer items-center justify-center rounded-xl border bg-white text-brand-700 transition-colors hover:bg-brand-50"
        >
          <LocateFixed className="size-4" aria-hidden />
        </button>
      )}
    </li>
  )
}
