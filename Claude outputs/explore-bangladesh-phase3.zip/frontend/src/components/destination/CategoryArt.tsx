import { CategoryIcon } from '@/components/common/CategoryIcon'
import { cn } from '@/lib/utils'
import type { CategorySummary, Image } from '@/types/api'

/**
 * Visual header for a destination. Shows the featured photo when one exists
 * (admins add photos in Phase 7); otherwise a tinted panel with the category icon.
 */
const TINTS: Record<string, string> = {
  beaches: 'from-[#0e7490] to-[#38bdf8]',
  islands: 'from-[#0f766e] to-[#2dd4bf]',
  'rivers-and-lakes': 'from-[#155e75] to-[#22d3ee]',
  waterfalls: 'from-[#0369a1] to-[#7dd3fc]',
  'mountains-and-hills': 'from-[#166534] to-[#4ade80]',
  'wildlife-and-forests': 'from-[#14532d] to-[#22c55e]',
  'natural-attractions': 'from-brand-800 to-brand-400',
  'parks-and-gardens': 'from-[#3f6212] to-[#a3e635]',
  'historical-places': 'from-[#7c2d12] to-[#f59e0b]',
  'archaeological-sites': 'from-[#78350f] to-[#d97706]',
  'religious-and-cultural-places': 'from-[#9a3412] to-[#fb923c]',
  museums: 'from-[#581c87] to-[#c084fc]',
  'famous-tourist-spots': 'from-[#9f1239] to-[#fb7185]',
}

export function CategoryArt({
  category,
  image,
  className,
  iconClassName,
}: {
  category: CategorySummary
  image?: Image | null
  className?: string
  iconClassName?: string
}) {
  return (
    <div
      className={cn(
        'relative flex items-center justify-center overflow-hidden bg-gradient-to-br text-white',
        TINTS[category.slug] ?? 'from-brand-800 to-brand-500',
        className,
      )}
    >
      {image?.url ? (
        <img src={image.url} alt={image.alt ?? ''} loading="lazy" className="absolute inset-0 size-full object-cover" />
      ) : (
        <>
          <div aria-hidden className="absolute -right-6 -top-8 size-28 rounded-full bg-white/10" />
          <div aria-hidden className="absolute -bottom-10 -left-6 size-24 rounded-full bg-black/10" />
          <CategoryIcon name={category.icon} className={cn('relative size-10 opacity-90', iconClassName)} />
        </>
      )}
    </div>
  )
}
