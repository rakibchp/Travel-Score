import { Home, Minus, Plus } from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode, type PointerEvent as ReactPointerEvent } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { useMapData } from '@/hooks/useMapData'
import { useI18n } from '@/i18n/useI18n'
import { fitBox, pathBox, project, type Box } from '@/lib/mapProjection'
import { cn } from '@/lib/utils'
import type { DestinationPin } from '@/types/api'

export type MapFocus =
  | { kind: 'country' }
  | { kind: 'division'; slug: string }
  | { kind: 'district'; slug: string }
  | { kind: 'pin'; id: string }

export type RegionName = { slug: string; name: string; nameBn: string; divisionSlug?: string }

type Props = {
  pins: DestinationPin[]
  visited: ReadonlySet<string>
  focus?: MapFocus
  /** Changing this number re-applies `focus` even if it didn't change (e.g. "locate" clicked twice). */
  focusNonce?: number
  selectedId?: string | null
  onSelectPin?: (id: string | null) => void
  renderPopup?: (pin: DestinationPin) => ReactNode
  /** Regions to emphasise; others are drawn muted. */
  highlightDivision?: string
  highlightDistrict?: string
  onRegionClick?: (kind: 'division' | 'district', slug: string) => void
  divisionNames?: RegionName[]
  districtNames?: RegionName[]
  className?: string
}

const MIN_WIDTH = 25 // most zoomed-in viewBox width (map units)
const PIN_PX = 7 // pin radius on screen (px), regardless of zoom
const PIN_PX_SMALL = 5 // on phone-width maps, where pins are denser
const ANIMATION_MS = 380

export function BangladeshMap({
  pins,
  visited,
  focus = { kind: 'country' },
  focusNonce = 0,
  selectedId = null,
  onSelectPin,
  renderPopup,
  highlightDivision,
  highlightDistrict,
  onRegionClick,
  divisionNames = [],
  districtNames = [],
  className,
}: Props) {
  const { t, lang } = useI18n()
  const { data: map, isLoading } = useMapData()
  // Callback ref: the container element changes when the loading placeholder is replaced by the map.
  const [containerEl, setContainerEl] = useState<HTMLDivElement | null>(null)
  const svgRef = useRef<SVGSVGElement>(null)
  const [size, setSize] = useState({ width: 0, height: 0 })
  const [view, setView] = useState<Box | null>(null)
  const viewRef = useRef<Box | null>(null)
  /** Keep the ref in step with state synchronously, so rapid pointer events read the latest view. */
  const commitView = useCallback((b: Box) => {
    viewRef.current = b
    setView(b)
  }, [])
  const animationRef = useRef<number | null>(null)

  /* ---------------- geometry ---------------- */

  const full: Box | null = useMemo(
    () => (map ? { x: map.viewBox[0], y: map.viewBox[1], w: map.viewBox[2], h: map.viewBox[3] } : null),
    [map],
  )
  const boxes = useMemo(() => {
    if (!map) return null
    return {
      division: new Map(map.divisions.map((d) => [d.slug, pathBox(d.d)])),
      district: new Map(map.districts.map((d) => [d.slug, pathBox(d.d)])),
    }
  }, [map])

  const projectedPins = useMemo(() => {
    if (!map) return []
    return pins
      .filter((p) => p.coordinates)
      .map((p) => {
        const [x, y] = project(p.coordinates as [number, number], map.projection)
        return { pin: p, x, y }
      })
  }, [pins, map])

  const nameOf = useCallback(
    (list: RegionName[], slug: string) => {
      const r = list.find((x) => x.slug === slug)
      return r ? (lang === 'bn' ? r.nameBn : r.name) : ''
    },
    [lang],
  )

  /* ---------------- sizing ---------------- */

  useEffect(() => {
    if (!containerEl) return
    const ro = new ResizeObserver(([entry]) => {
      if (!entry) return
      setSize({ width: entry.contentRect.width, height: entry.contentRect.height })
    })
    ro.observe(containerEl)
    return () => ro.disconnect()
  }, [containerEl])

  const aspect = size.width > 0 && size.height > 0 ? size.width / size.height : 0.75

  const clamp = useCallback(
    (b: Box): Box => {
      if (!full) return b
      const maxW = full.w * 1.4
      let w = Math.min(Math.max(b.w, MIN_WIDTH), maxW)
      let h = w / aspect
      if (h > full.h * 1.4) {
        h = full.h * 1.4
        w = h * aspect
      }
      const cx = Math.min(Math.max(b.x + b.w / 2, full.x), full.x + full.w)
      const cy = Math.min(Math.max(b.y + b.h / 2, full.y), full.y + full.h)
      return { x: cx - w / 2, y: cy - h / 2, w, h }
    },
    [full, aspect],
  )

  const animateTo = useCallback(
    (target: Box) => {
      const start = viewRef.current
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
      if (!start || reduce) {
        commitView(target)
        return
      }
      const t0 = performance.now()
      const step = (now: number) => {
        const k = Math.min(1, (now - t0) / ANIMATION_MS)
        const e = 1 - Math.pow(1 - k, 3)
        commitView({
          x: start.x + (target.x - start.x) * e,
          y: start.y + (target.y - start.y) * e,
          w: start.w + (target.w - start.w) * e,
          h: start.h + (target.h - start.h) * e,
        })
        if (k < 1) animationRef.current = requestAnimationFrame(step)
      }
      animationRef.current = requestAnimationFrame(step)
    },
    [commitView],
  )

  const boxForFocus = useCallback((): Box | null => {
    if (!full || !boxes) return null
    if (focus.kind === 'division') {
      const b = boxes.division.get(focus.slug)
      if (b) return fitBox(b, aspect, 0.08)
    }
    if (focus.kind === 'district') {
      const b = boxes.district.get(focus.slug)
      if (b) return fitBox(b, aspect, 0.2)
    }
    if (focus.kind === 'pin') {
      const p = projectedPins.find((x) => x.pin.id === focus.id)
      if (p) return fitBox({ x: p.x - 110, y: p.y - 110, w: 220, h: 220 }, aspect, 0)
    }
    return fitBox(full, aspect, 0.02)
  }, [full, boxes, focus, aspect, projectedPins])

  // Apply focus when it (or the container shape) changes.
  const focusKey = `${focus.kind}:${'slug' in focus ? focus.slug : 'id' in focus ? focus.id : ''}:${focusNonce}`
  const lastAppliedRef = useRef<string>('')
  useEffect(() => {
    if (!size.width) return
    const target = boxForFocus()
    if (!target) return
    const key = `${focusKey}|${Math.round(aspect * 100)}`
    if (lastAppliedRef.current === key) return
    const firstPaint = lastAppliedRef.current === ''
    lastAppliedRef.current = key
    if (firstPaint) commitView(target)
    else animateTo(clamp(target))
  }, [focusKey, aspect, size.width, boxForFocus, animateTo, clamp, commitView])

  useEffect(() => () => {
    if (animationRef.current) cancelAnimationFrame(animationRef.current)
  }, [])

  /* ---------------- interaction ---------------- */

  const toMap = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current
    const v = viewRef.current
    if (!svg || !v) return { x: 0, y: 0 }
    const r = svg.getBoundingClientRect()
    return { x: v.x + ((clientX - r.left) / r.width) * v.w, y: v.y + ((clientY - r.top) / r.height) * v.h }
  }, [])

  const zoomAt = useCallback(
    (factor: number, cx?: number, cy?: number) => {
      const v = viewRef.current
      if (!v) return
      const px = cx ?? v.x + v.w / 2
      const py = cy ?? v.y + v.h / 2
      const w = v.w * factor
      const h = v.h * factor
      const next = clamp({ x: px - (px - v.x) * factor, y: py - (py - v.y) * factor, w, h })
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      commitView(next)
    },
    [clamp, commitView],
  )

  // Wheel zoom (non-passive so the page doesn't scroll while zooming the map).
  useEffect(() => {
    const svg = svgRef.current
    if (!svg) return
    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      const { x, y } = toMap(e.clientX, e.clientY)
      zoomAt(Math.exp(e.deltaY * 0.0015), x, y)
    }
    svg.addEventListener('wheel', onWheel, { passive: false })
    return () => svg.removeEventListener('wheel', onWheel)
  }, [toMap, zoomAt, map])

  const pointers = useRef(new Map<number, { x: number; y: number }>())
  const gesture = useRef<{ moved: number; lastDist?: number }>({ moved: 0 })

  const onPointerDown = (e: ReactPointerEvent<SVGSVGElement>) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (pointers.current.size === 1) gesture.current = { moved: 0 }
    // No pointer capture yet: capturing here would retarget the click away from pins/regions.
    if (animationRef.current) cancelAnimationFrame(animationRef.current)
  }

  const onPointerMove = (e: ReactPointerEvent<SVGSVGElement>) => {
    const prev = pointers.current.get(e.pointerId)
    if (!prev || !svgRef.current || !viewRef.current) return
    const r = svgRef.current.getBoundingClientRect()
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })

    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()] as [{ x: number; y: number }, { x: number; y: number }]
      const dist = Math.hypot(a.x - b.x, a.y - b.y)
      const mid = toMap((a.x + b.x) / 2, (a.y + b.y) / 2)
      if (gesture.current.lastDist) zoomAt(gesture.current.lastDist / dist, mid.x, mid.y)
      gesture.current.lastDist = dist
      gesture.current.moved += 10
      return
    }

    const dx = e.clientX - prev.x
    const dy = e.clientY - prev.y
    gesture.current.moved += Math.abs(dx) + Math.abs(dy)
    // Once it's clearly a drag, capture the pointer so panning continues outside the map.
    if (gesture.current.moved >= 6 && !e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.setPointerCapture(e.pointerId)
    }
    const v = viewRef.current
    commitView(clamp({ ...v, x: v.x - (dx / r.width) * v.w, y: v.y - (dy / r.height) * v.h }))
  }

  const onPointerUp = (e: ReactPointerEvent<SVGSVGElement>) => {
    pointers.current.delete(e.pointerId)
    if (pointers.current.size < 2) gesture.current.lastDist = undefined
  }

  /** A tap is a pointer-up that didn't move enough to count as a drag. */
  const isTap = () => gesture.current.moved < 6

  /* ---------------- render ---------------- */

  if (isLoading || !map || !full) {
    return (
      <div ref={setContainerEl} className={cn('relative overflow-hidden rounded-2xl border bg-[#e8f1ef]', className)}>
        <Skeleton className="absolute inset-0 rounded-none" />
        <span className="sr-only">{t('map.loading')}</span>
      </div>
    )
  }

  const v = view ?? fitBox(full, aspect, 0.02)
  const unitsPerPx = size.width ? v.w / size.width : 1
  const pinR = (size.width && size.width < 500 ? PIN_PX_SMALL : PIN_PX) * unitsPerPx
  const zoomedIn = v.w < full.w * 0.45
  const selected = projectedPins.find((p) => p.pin.id === selectedId)

  const popupStyle =
    selected && size.width
      ? {
          left: Math.min(Math.max(((selected.x - v.x) / v.w) * size.width, 140), size.width - 140),
          top: ((selected.y - v.y) / v.h) * size.height,
        }
      : null

  return (
    <div ref={setContainerEl} className={cn('relative overflow-hidden rounded-2xl border bg-[#e8f1ef]', className)}>
      <svg
        ref={svgRef}
        role="img"
        aria-label={t('map.label')}
        viewBox={`${v.x} ${v.y} ${v.w} ${v.h}`}
        className="size-full touch-none select-none"
        style={{ cursor: 'grab' }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onClick={(e) => {
          if (e.target === svgRef.current && isTap()) onSelectPin?.(null)
        }}
      >
        <g>
          {map.districts.map((d) => {
            const muted =
              (highlightDistrict && d.slug !== highlightDistrict) ||
              (highlightDivision && !districtInDivision(d.slug, highlightDivision, districtNames))
            return (
              <path
                key={d.slug}
                d={d.d}
                className={cn(
                  'transition-[fill] duration-200',
                  onRegionClick && 'cursor-pointer hover:fill-[#ecdcc4]',
                )}
                fill={muted ? '#f3eee6' : '#f6ead9'}
                stroke="#dcc8ad"
                strokeWidth={0.9 * unitsPerPx}
                onClick={() => {
                  if (onRegionClick && isTap()) onRegionClick('district', d.slug)
                }}
              />
            )
          })}
          {map.divisions.map((d) => (
            <path
              key={d.slug}
              d={d.d}
              fill="none"
              stroke={highlightDivision === d.slug ? '#006a4e' : '#8db8b2'}
              strokeWidth={(highlightDivision === d.slug ? 2.4 : 1.6) * unitsPerPx}
              pointerEvents="none"
            />
          ))}
        </g>

        {/* Labels: divisions when zoomed out, districts when zoomed in */}
        <g pointerEvents="none" className="font-bengali">
          {!zoomedIn
            ? map.divisions.map((d) => (
                <text
                  key={d.slug}
                  x={d.label[0]}
                  y={d.label[1]}
                  textAnchor="middle"
                  fontSize={13 * unitsPerPx}
                  fill="#9a7b5a"
                  fontWeight={600}
                  opacity={0.9}
                >
                  {nameOf(divisionNames, d.slug)}
                </text>
              ))
            : map.districts.map((d) => (
                <text
                  key={d.slug}
                  x={d.label[0]}
                  y={d.label[1]}
                  textAnchor="middle"
                  fontSize={11 * unitsPerPx}
                  fill="#a2876a"
                  opacity={0.85}
                >
                  {nameOf(districtNames, d.slug)}
                </text>
              ))}
        </g>

        <g>
          {projectedPins.map(({ pin, x, y }) => {
            const isVisited = visited.has(pin.id)
            const isSelected = pin.id === selectedId
            return (
              <g key={pin.id}>
                {isSelected && (
                  <circle cx={x} cy={y} r={pinR * 2.4} fill="#006a4e" opacity={0.18} pointerEvents="none">
                    <animate attributeName="r" values={`${pinR * 1.6};${pinR * 2.8};${pinR * 1.6}`} dur="1.6s" repeatCount="indefinite" />
                  </circle>
                )}
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? pinR * 1.35 : pinR}
                  fill={isVisited ? '#006a4e' : '#ffffff'}
                  stroke={isVisited ? '#ffffff' : '#006a4e'}
                  strokeWidth={2 * unitsPerPx}
                  className="cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation()
                    if (isTap()) onSelectPin?.(isSelected ? null : pin.id)
                  }}
                >
                  <title>{lang === 'bn' ? pin.nameBn : pin.name}</title>
                </circle>
              </g>
            )
          })}
        </g>
      </svg>

      {/* Popup for the selected pin */}
      {selected && popupStyle && renderPopup && (
        <div
          className="pointer-events-none absolute z-10 w-[260px] -translate-x-1/2"
          style={{
            left: popupStyle.left,
            top: popupStyle.top,
            transform: `translate(-50%, ${popupStyle.top > size.height / 2 ? 'calc(-100% - 16px)' : '16px'})`,
          }}
        >
          <div className="pointer-events-auto animate-fade-up rounded-2xl border bg-white p-3 shadow-lg">
            {renderPopup(selected.pin)}
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="absolute bottom-3 right-3 flex flex-col gap-2">
        <MapButton label={t('map.zoomIn')} onClick={() => zoomAt(0.6)}>
          <Plus />
        </MapButton>
        <MapButton label={t('map.zoomOut')} onClick={() => zoomAt(1 / 0.6)}>
          <Minus />
        </MapButton>
        <MapButton
          label={t('map.reset')}
          onClick={() => {
            onSelectPin?.(null)
            animateTo(fitBox(full, aspect, 0.02))
          }}
        >
          <Home />
        </MapButton>
      </div>

      <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-3 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-medium text-muted-foreground shadow-sm">
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-full border-2 border-primary bg-white" aria-hidden />
          {t('map.legendNotVisited')}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-full bg-primary" aria-hidden />
          {t('map.legendVisited')}
        </span>
      </div>

      <p className="pointer-events-none absolute bottom-3 left-3 hidden max-w-[70%] rounded-full bg-white/90 px-3 py-1.5 text-[11px] text-muted-foreground shadow-sm sm:block">
        {t('map.hint')}
      </p>
    </div>
  )
}

/** Uses the divisionSlug carried on district names; if it's unknown nothing is muted. */
function districtInDivision(districtSlug: string, divisionSlug: string, districts: RegionName[]) {
  const d = districts.find((x) => x.slug === districtSlug)
  return d?.divisionSlug ? d.divisionSlug === divisionSlug : true
}

function MapButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="flex size-10 cursor-pointer items-center justify-center rounded-xl border bg-white text-foreground shadow-sm transition-colors hover:bg-brand-50 [&_svg]:size-4"
    >
      {children}
    </button>
  )
}
