import { Link } from 'react-router'
import { Container } from '@/components/layout/Container'
import { Logo } from '@/components/layout/Logo'
import { useI18n } from '@/i18n/useI18n'

const YEAR = new Date().getFullYear()

export function SiteFooter() {
  const { t, n } = useI18n()
  return (
    <footer className="mt-20 bg-brand-950 text-brand-100">
      <div aria-hidden className="h-1 bg-gradient-to-r from-brand-700 via-flag-red to-brand-700" />
      <Container className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2">
          <Logo light />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-brand-200">{t('footer.about')}</p>
        </div>
        <nav aria-label={t('footer.explore')} className="text-sm">
          <h2 className="mb-3 font-semibold text-white">{t('footer.explore')}</h2>
          <ul className="space-y-2">
            <li><Link className="hover:text-white" to="/explore">{t('footer.allDestinations')}</Link></li>
            <li><Link className="hover:text-white" to="/divisions">{t('footer.divisionsDistricts')}</Link></li>
            <li><Link className="hover:text-white" to="/scorecard">{t('footer.myScorecard')}</Link></li>
          </ul>
        </nav>
        <nav aria-label={t('footer.account')} className="text-sm">
          <h2 className="mb-3 font-semibold text-white">{t('footer.account')}</h2>
          <ul className="space-y-2">
            <li><Link className="hover:text-white" to="/login">{t('footer.signIn')}</Link></li>
            <li><Link className="hover:text-white" to="/register">{t('footer.register')}</Link></li>
          </ul>
        </nav>
      </Container>
      <div className="border-t border-white/10">
        <Container className="flex flex-col gap-2 py-5 text-xs text-brand-300 sm:flex-row sm:items-center sm:justify-between">
          <p>{t('footer.rights', { year: n(YEAR, { useGrouping: false }) })}</p>
          <p>
            {t('footer.strip')} · {t('footer.mapCredit')}
          </p>
        </Container>
      </div>
    </footer>
  )
}
