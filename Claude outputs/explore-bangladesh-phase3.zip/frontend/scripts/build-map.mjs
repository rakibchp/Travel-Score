#!/usr/bin/env node
/**
 * Builds src/data/bangladesh-map.json — simplified, pre-projected SVG paths for
 * Bangladesh's 64 districts and 8 divisions. Run once; the output is committed,
 * so the app needs no map library or tile server at runtime.
 *
 * Source: geoBoundaries gbOpen BGD ADM1 + ADM2 (simplified), CC BY 4.0
 *   https://www.geoboundaries.org/  ·  commit 9469f09
 *   ADM1: https://media.githubusercontent.com/media/wmgeolab/geoBoundaries/9469f09/releaseData/gbOpen/BGD/ADM1/geoBoundaries-BGD-ADM1_simplified.geojson
 *   ADM2: https://media.githubusercontent.com/media/wmgeolab/geoBoundaries/9469f09/releaseData/gbOpen/BGD/ADM2/geoBoundaries-BGD-ADM2_simplified.geojson
 *
 * Usage: node scripts/build-map.mjs <ADM1.geojson> <ADM2.geojson>
 *
 * The projection (Web Mercator, fitted to a 1000-unit-wide viewBox) is written
 * into the JSON so the frontend can place destination pins with exactly the
 * same math (see src/lib/mapProjection.ts).
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const [adm1Path, adm2Path] = process.argv.slice(2)
if (!adm1Path || !adm2Path) {
  console.error('Usage: node scripts/build-map.mjs <ADM1.geojson> <ADM2.geojson>')
  process.exit(1)
}

// geoBoundaries spellings -> the slugs used in our database
const NAME_FIXES = {
  Barisal: 'Barishal',
  Bogra: 'Bogura',
  Brahamanbaria: 'Brahmanbaria',
  Chittagong: 'Chattogram',
  Comilla: 'Cumilla',
  Jessore: 'Jashore',
  Maulvibazar: 'Moulvibazar',
  Nawabganj: 'Chapainawabganj',
  Netrakona: 'Netrokona',
  Rajshani: 'Rajshahi',
}
const slugify = (s) =>
  (NAME_FIXES[s] ?? s)
    .normalize('NFKD')
    .toLowerCase()
    .replace(/['’]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')

const WIDTH = 1000
const PADDING = 12
const TOLERANCE_DEG = 0.004 // ~400 m; keeps coastlines recognisable at small sizes
const MIN_RING_AREA = 0.0004 // drop tiny islets (deg²) that would only add noise

const toRad = (d) => (d * Math.PI) / 180
const mercY = (lat) => (Math.log(Math.tan(Math.PI / 4 + toRad(lat) / 2)) * 180) / Math.PI

/** Douglas–Peucker line simplification. */
function simplify(points, tol) {
  if (points.length <= 3) return points
  const sq = tol * tol
  const keep = new Uint8Array(points.length)
  keep[0] = keep[points.length - 1] = 1
  const stack = [[0, points.length - 1]]
  while (stack.length) {
    const [a, b] = stack.pop()
    const [ax, ay] = points[a]
    const [bx, by] = points[b]
    const dx = bx - ax
    const dy = by - ay
    const len = dx * dx + dy * dy
    let maxD = 0
    let idx = -1
    for (let i = a + 1; i < b; i++) {
      const [px, py] = points[i]
      let t = len ? ((px - ax) * dx + (py - ay) * dy) / len : 0
      t = Math.max(0, Math.min(1, t))
      const ex = ax + t * dx - px
      const ey = ay + t * dy - py
      const d = ex * ex + ey * ey
      if (d > maxD) {
        maxD = d
        idx = i
      }
    }
    if (maxD > sq && idx > 0) {
      keep[idx] = 1
      stack.push([a, idx], [idx, b])
    }
  }
  return points.filter((_, i) => keep[i])
}

function ringArea(ring) {
  let a = 0
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    a += (ring[j][0] + ring[i][0]) * (ring[j][1] - ring[i][1])
  }
  return Math.abs(a / 2)
}

const polygonsOf = (geometry) => (geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates)

const adm1 = JSON.parse(readFileSync(adm1Path, 'utf8'))
const adm2 = JSON.parse(readFileSync(adm2Path, 'utf8'))

// Fit the projection to the national bounding box.
let minLng = Infinity
let maxLng = -Infinity
let minLat = Infinity
let maxLat = -Infinity
for (const f of adm2.features) {
  for (const poly of polygonsOf(f.geometry)) {
    for (const [lng, lat] of poly[0]) {
      minLng = Math.min(minLng, lng)
      maxLng = Math.max(maxLng, lng)
      minLat = Math.min(minLat, lat)
      maxLat = Math.max(maxLat, lat)
    }
  }
}
const scale = (WIDTH - PADDING * 2) / (maxLng - minLng)
const height = Math.ceil((mercY(maxLat) - mercY(minLat)) * scale + PADDING * 2)
const projection = { minLng, maxMercY: mercY(maxLat), scale, padding: PADDING }

const project = ([lng, lat]) => [
  (lng - minLng) * scale + PADDING,
  (projection.maxMercY - mercY(lat)) * scale + PADDING,
]
const fmt = (n) => Math.round(n * 10) / 10

function toPath(geometry) {
  const parts = []
  for (const poly of polygonsOf(geometry)) {
    poly.forEach((ring, i) => {
      if (i === 0 && ringArea(ring) < MIN_RING_AREA && polygonsOf(geometry).length > 1) return
      if (i > 0 && ringArea(ring) < MIN_RING_AREA) return
      const simplified = simplify(ring, TOLERANCE_DEG)
      if (simplified.length < 4) return
      const pts = simplified.map(project)
      parts.push('M' + pts.map(([x, y]) => `${fmt(x)} ${fmt(y)}`).join('L') + 'Z')
    })
  }
  return parts.join('')
}

/** Label anchor: area-weighted centroid of the largest ring, projected. */
function labelPoint(geometry) {
  const rings = polygonsOf(geometry).map((p) => p[0])
  const ring = rings.reduce((a, b) => (ringArea(b) > ringArea(a) ? b : a))
  let cx = 0
  let cy = 0
  let a = 0
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const f = ring[j][0] * ring[i][1] - ring[i][0] * ring[j][1]
    cx += (ring[j][0] + ring[i][0]) * f
    cy += (ring[j][1] + ring[i][1]) * f
    a += f
  }
  const [x, y] = project([cx / (3 * a), cy / (3 * a)])
  return [fmt(x), fmt(y)]
}

const divisions = adm1.features
  .map((f) => ({ slug: slugify(f.properties.shapeName), d: toPath(f.geometry), label: labelPoint(f.geometry) }))
  .sort((a, b) => a.slug.localeCompare(b.slug))

const districts = adm2.features
  .map((f) => ({ slug: slugify(f.properties.shapeName), d: toPath(f.geometry), label: labelPoint(f.geometry) }))
  .sort((a, b) => a.slug.localeCompare(b.slug))

if (divisions.length !== 8 || districts.length !== 64) {
  throw new Error(`Expected 8 divisions and 64 districts, got ${divisions.length} and ${districts.length}`)
}

const out = {
  attribution: 'Boundaries © geoBoundaries (geoboundaries.org), CC BY 4.0',
  viewBox: [0, 0, WIDTH, height],
  projection,
  divisions,
  districts,
}

const here = dirname(fileURLToPath(import.meta.url))
const target = resolve(here, '../src/data/bangladesh-map.json')
mkdirSync(dirname(target), { recursive: true })
writeFileSync(target, JSON.stringify(out))
console.log(`Wrote ${target} (${(JSON.stringify(out).length / 1024).toFixed(1)} KB, viewBox ${WIDTH}×${height})`)
