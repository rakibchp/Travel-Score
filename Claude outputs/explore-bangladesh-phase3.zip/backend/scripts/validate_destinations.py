"""Validate the destination seed: district coverage, categories, duplicates, text length,
and that every coordinate falls inside its district polygon.

Usage: python3 scripts/validate_destinations.py <geoBoundaries-BGD-ADM2_simplified.geojson>
(ADM2 download URL is in frontend/scripts/build-map.mjs.) Exit code 1 on any error."""
import json, glob, sys, math, os
from collections import Counter, defaultdict
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'seed', 'data')
if len(sys.argv) < 2:
    sys.exit(__doc__)
ALIAS={'Barisal':'Barishal','Bogra':'Bogura','Brahamanbaria':'Brahmanbaria','Chittagong':'Chattogram','Comilla':'Cumilla','Jessore':'Jashore','Maulvibazar':'Moulvibazar','Nawabganj':'Chapainawabganj','Netrakona':'Netrokona'}
districts=[d['name'] for d in json.load(open(f'{ROOT}/districts.json'))]
cats={c['name'].lower().replace(' and ','-and-').replace(' ','-') for c in json.load(open(f'{ROOT}/categories.json'))}
geo=json.load(open(sys.argv[1]))
polys={}
for f in geo['features']:
    n=ALIAS.get(f['properties']['shapeName'],f['properties']['shapeName'])
    g=f['geometry']; polys[n]=[g['coordinates']] if g['type']=='Polygon' else g['coordinates']
assert set(polys)==set(districts), set(polys)^set(districts)
def in_ring(x,y,ring):
    inside=False; j=len(ring)-1
    for i in range(len(ring)):
        xi,yi=ring[i][:2]; xj,yj=ring[j][:2]
        if (yi>y)!=(yj>y) and x < (xj-xi)*(y-yi)/(yj-yi)+xi: inside=not inside
        j=i
    return inside
def in_district(x,y,name):
    return any(in_ring(x,y,p[0]) and not any(in_ring(x,y,h) for h in p[1:]) for p in polys[name])
def nearest_km(x,y,name):
    best=1e9
    for p in polys[name]:
        for px,py in p[0]:
            d=math.hypot((px-x)*math.cos(math.radians(y))*111,(py-y)*111); best=min(best,d)
    return best
items=[]
for fn in sorted(glob.glob(f'{ROOT}/destinations/*.json')):
    for d in json.load(open(fn)): d['_file']=fn.split('/')[-1]; items.append(d)
errors=[]; warns=[]
names=Counter(d['name'] for d in items)
for n,c in names.items():
    if c>1: errors.append(f'duplicate name {n}')
cov=Counter(d['district'] for d in items)
for dist in districts:
    if cov[dist]==0: errors.append(f'no destinations in {dist}')
for d in items:
    if d['district'] not in polys: errors.append(f"{d['name']}: unknown district {d['district']}"); continue
    if d['category'] not in cats: errors.append(f"{d['name']}: unknown category {d['category']}")
    if len(d['short'])>200: errors.append(f"{d['name']}: short too long {len(d['short'])}")
    if len(d['shortBn'])>300: errors.append(f"{d['name']}: shortBn too long")
    if not in_district(d['lng'],d['lat'],d['district']):
        km=nearest_km(d['lng'],d['lat'],d['district'])
        hits=[n for n in polys if in_district(d['lng'],d['lat'],n)]
        (errors if km>3 else warns).append(f"{d['name']} ({d['district']}): point outside district by ~{km:.1f} km; inside {hits or 'none (water/outside)'}")
print(f"{len(items)} destinations, {len(cov)} / 64 districts covered, featured={sum(1 for d in items if d.get('featured'))}")
print('per category:', dict(Counter(d['category'] for d in items)))
for w in warns: print('WARN ', w)
for e in errors: print('ERROR', e)
sys.exit(1 if errors else 0)
