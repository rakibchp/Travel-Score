/**
 * Score engine integration tests. They need a disposable MongoDB:
 *   MONGODB_URI_TEST=mongodb://127.0.0.1:27017/eb-test npm test
 * The database named in MONGODB_URI_TEST is wiped at the start and end of the run.
 */
import assert from 'node:assert/strict';
import { after, before, beforeEach, describe, it } from 'node:test';

const TEST_URI = process.env.MONGODB_URI_TEST;
if (!TEST_URI) {
  console.warn('Skipping score tests: set MONGODB_URI_TEST to a disposable database.');
  process.exit(0);
}
if (/prod|production/i.test(TEST_URI)) throw new Error('Refusing to run tests against a database that looks like production');
process.env.MONGODB_URI = TEST_URI;
process.env.NODE_ENV = 'test';

const mongoose = (await import('mongoose')).default;
const { connectDB, disconnectDB } = await import('../config/db.js');
const { Division } = await import('../models/Division.js');
const { District } = await import('../models/District.js');
const { DestinationCategory } = await import('../models/DestinationCategory.js');
const { Destination } = await import('../models/Destination.js');
const { computeScorecard, invalidateScoreTotals, percent } = await import('../services/score.service.js');
const { createApp } = await import('../app.js');

type Ids = Record<string, string>;
const ids: Ids = {};

async function seedFixtures() {
  await mongoose.connection.db!.dropDatabase();
  const [dhaka, sylhet] = await Division.create([
    { name: 'Dhaka', nameBn: 'ঢাকা', slug: 'dhaka', order: 1 },
    { name: 'Sylhet', nameBn: 'সিলেট', slug: 'sylhet', order: 2 },
  ]);
  const [dhakaD, gazipur, sylhetD] = await District.create([
    { name: 'Dhaka', nameBn: 'ঢাকা', slug: 'dhaka', division: dhaka!._id },
    { name: 'Gazipur', nameBn: 'গাজীপুর', slug: 'gazipur', division: dhaka!._id },
    { name: 'Sylhet', nameBn: 'সিলেট', slug: 'sylhet', division: sylhet!._id },
  ]);
  const [hist, nature] = await DestinationCategory.create([
    { name: 'Historical Places', nameBn: 'ঐতিহাসিক স্থান', slug: 'historical-places', order: 1 },
    { name: 'Natural Attractions', nameBn: 'প্রাকৃতিক', slug: 'natural-attractions', order: 2 },
  ]);
  const base = (name: string, district: typeof dhakaD, division: typeof dhaka, category: typeof hist, extra = {}) => ({
    name,
    nameBn: name,
    slug: name.toLowerCase().replace(/\s+/g, '-'),
    district: district!._id,
    division: division!._id,
    category: category!._id,
    shortDescription: name,
    location: { type: 'Point' as const, coordinates: [90.4, 23.7] },
    ...extra,
  });
  const docs = await Destination.insertMany([
    base('Fort', dhakaD, dhaka, hist),
    base('Museum', dhakaD, dhaka, hist),
    base('Forest', gazipur, dhaka, nature),
    base('Hills', sylhetD, sylhet, nature, { isFeatured: true }),
    base('Closed Place', sylhetD, sylhet, nature, { isActive: false }),
  ]);
  for (const d of docs) ids[d.slug] = String(d._id);
  ids.dhakaDistrict = String(dhakaD!._id);
  ids.sylhetDivision = String(sylhet!._id);
  invalidateScoreTotals();
}

before(async () => {
  await connectDB();
  await seedFixtures();
});
beforeEach(() => invalidateScoreTotals());
after(async () => {
  await mongoose.connection.db?.dropDatabase();
  await disconnectDB();
});

describe('percent()', () => {
  it('rounds to one decimal and never divides by zero', () => {
    assert.equal(percent(1, 3), 33.3);
    assert.equal(percent(2, 3), 66.7);
    assert.equal(percent(5, 0), 0);
    assert.equal(percent(4, 4), 100);
  });
});

describe('computeScorecard()', () => {
  it('scores zero for an empty list, with totals counting active destinations only', async () => {
    const s = await computeScorecard([]);
    assert.equal(s.score, 0);
    assert.equal(s.totalDestinations, 4); // "Closed Place" is inactive
    assert.equal(s.percentage, 0);
    assert.equal(s.totalDistricts, 3);
    assert.equal(s.totalDivisions, 2);
    assert.equal(s.districtsExplored, 0);
    assert.deepEqual(s.ignoredIds, []);
  });

  it('counts each destination once, however many times it is sent', async () => {
    const s = await computeScorecard([ids.fort!, ids.fort!, ids.fort!]);
    assert.equal(s.score, 1);
    assert.equal(s.percentage, 25);
  });

  it('ignores inactive, unknown and malformed ids and reports them', async () => {
    const unknown = new mongoose.Types.ObjectId().toString();
    const s = await computeScorecard([ids.fort!, ids['closed-place']!, unknown, 'not-an-id', '{"$gt":""}']);
    assert.equal(s.score, 1);
    assert.deepEqual(new Set(s.ignoredIds), new Set([ids['closed-place'], unknown, 'not-an-id', '{"$gt":""}']));
  });

  it('breaks the score down by division, district and category consistently', async () => {
    const s = await computeScorecard([ids.fort!, ids.museum!, ids.hills!]);
    assert.equal(s.score, 3);
    assert.equal(s.districtsExplored, 2);
    assert.equal(s.divisionsExplored, 2);
    assert.equal(s.categoriesExplored, 2);
    const sum = (rows: Array<{ visited: number }>) => rows.reduce((a, r) => a + r.visited, 0);
    assert.equal(sum(s.byDivision), 3);
    assert.equal(sum(s.byDistrict), 3);
    assert.equal(sum(s.byCategory), 3);
    const dhakaDistrict = s.byDistrict.find((d) => d.id === ids.dhakaDistrict)!;
    assert.deepEqual([dhakaDistrict.visited, dhakaDistrict.total], [2, 2]);
    const sylhet = s.byDivision.find((d) => d.id === ids.sylhetDivision)!;
    assert.deepEqual([sylhet.visited, sylhet.total], [1, 1]); // the inactive place is not in the total
  });

  it('reaches 100% when every active destination is visited', async () => {
    const s = await computeScorecard([ids.fort!, ids.museum!, ids.forest!, ids.hills!, ids['closed-place']!]);
    assert.equal(s.score, 4);
    assert.equal(s.percentage, 100);
  });

  it('suggests unvisited places, featured first, at most one per district', async () => {
    const s = await computeScorecard([ids.forest!], { suggestions: 5 });
    const slugs = s.suggestions.map((d) => d.slug);
    assert.equal(slugs[0], 'hills'); // featured
    assert.ok(!slugs.includes('forest')); // already visited
    assert.ok(!slugs.includes('closed-place')); // inactive
    const districts = s.suggestions.map((d) => d.district.id);
    assert.equal(new Set(districts).size, districts.length); // one per district
    assert.equal(s.suggestions.length, 2); // Dhaka + Sylhet districts (Gazipur only had the visited place)
  });

  it('picks up new destinations after the totals cache is invalidated', async () => {
    const before = await computeScorecard([]);
    await Destination.updateOne({ slug: 'closed-place' }, { isActive: true });
    invalidateScoreTotals();
    const afterActivate = await computeScorecard([]);
    assert.equal(afterActivate.totalDestinations, before.totalDestinations + 1);
    await Destination.updateOne({ slug: 'closed-place' }, { isActive: false });
  });
});

describe('POST /api/v1/score/preview', () => {
  const app = createApp();
  let base = '';
  let server: ReturnType<typeof app.listen>;
  before(async () => {
    await new Promise<void>((resolve) => {
      server = app.listen(0, () => resolve());
    });
    const addr = server.address();
    base = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}/api/v1`;
  });
  after(() => new Promise<void>((resolve) => server.close(() => resolve())));

  const post = (body: unknown) =>
    fetch(`${base}/score/preview`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

  it('returns a scorecard and is never cached', async () => {
    const res = await post({ destinationIds: [ids.fort, ids.hills] });
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('cache-control'), 'private, no-store');
    const body = (await res.json()) as { data: { score: number; suggestions: unknown[] } };
    assert.equal(body.data.score, 2);
    assert.ok(Array.isArray(body.data.suggestions));
  });

  it('ignores any score the client tries to send', async () => {
    const res = await post({ destinationIds: [ids.fort], score: 999 });
    const body = (await res.json()) as { data: { score: number } };
    assert.equal(body.data.score, 1);
  });

  it('rejects bad bodies with a validation error', async () => {
    for (const bad of [{}, { destinationIds: 'x' }, { destinationIds: Array(2001).fill(ids.fort) }, { destinationIds: [{ $ne: null }] }]) {
      const res = await post(bad);
      assert.equal(res.status, 400, JSON.stringify(bad).slice(0, 60));
      const body = (await res.json()) as { error: { code: string } };
      assert.equal(body.error.code, 'VALIDATION_ERROR');
    }
  });
});
