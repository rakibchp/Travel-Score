import { z } from 'zod';

/** Guest preview: the ids kept in the browser. Malformed ids are not an error — they're reported back as ignored. */
export const scorePreviewBody = z.object({
  destinationIds: z.array(z.string().max(64)).max(2000, 'at most 2000 destinations'),
  suggestions: z.number().int().min(0).max(12).default(6),
});

export type ScorePreviewBody = z.infer<typeof scorePreviewBody>;
