import { isValidObjectId } from 'mongoose';
import { z } from 'zod';

export const slugParam = z
  .string()
  .trim()
  .toLowerCase()
  .max(80)
  .regex(/^[a-z0-9-]+$/, 'must be a slug (letters, numbers, hyphens)');

/** "id1,id2,…" -> validated ObjectId strings (max 500, so URLs stay reasonable). */
const idList = z
  .string()
  .max(500 * 25)
  .transform((v) => [...new Set(v.split(',').map((s) => s.trim()).filter(Boolean))])
  .refine((ids) => ids.length <= 500, 'at most 500 ids')
  .refine((ids) => ids.every((id) => isValidObjectId(id)), 'contains an invalid id');

export const destinationListQuery = z
  .object({
    q: z.string().trim().max(80).optional(),
    division: slugParam.optional(),
    district: slugParam.optional(),
    category: slugParam.optional(),
    /** Only these destinations (guest "visited" view uses the ids kept in the browser). */
    ids: idList.optional(),
    /** Everything except these destinations (guest "not visited yet" view). */
    excludeIds: idList.optional(),
    sort: z.enum(['popular', 'name']).default('popular'),
    page: z.coerce.number().int().min(1).max(1000).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(24),
  })
  .refine((v) => !(v.ids && v.excludeIds), { message: 'use either ids or excludeIds, not both', path: ['ids'] });

export type DestinationListQuery = z.infer<typeof destinationListQuery>;

export const showcaseQuery = z.object({
  limit: z.coerce.number().int().min(1).max(24).default(8),
});

export type ShowcaseQuery = z.infer<typeof showcaseQuery>;

export const slugParams = z.object({ slug: slugParam });
export type SlugParams = z.infer<typeof slugParams>;
