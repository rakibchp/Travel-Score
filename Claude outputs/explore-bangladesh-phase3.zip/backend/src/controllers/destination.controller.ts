import type { Request, Response } from 'express';
import {
  getDestinationBySlug,
  listDestinations,
  listFeatured,
  listPins,
  listPopular,
} from '../services/destination.service.js';
import { sendSuccess } from '../utils/response.js';
import type { DestinationListQuery, ShowcaseQuery, SlugParams } from '../validators/destination.validators.js';

const SHORT_CACHE = 'public, s-maxage=60, stale-while-revalidate=600';

export async function getDestinations(_req: Request, res: Response) {
  const query = res.locals.query as DestinationListQuery;
  const { items, meta } = await listDestinations(query);
  // Lists filtered by a visitor's own ids are personal; don't let a CDN share them.
  res.set('Cache-Control', query.ids || query.excludeIds ? 'private, no-store' : SHORT_CACHE);
  sendSuccess(res, items, meta);
}

export async function getPins(_req: Request, res: Response) {
  res.set('Cache-Control', SHORT_CACHE);
  sendSuccess(res, await listPins());
}

export async function getFeatured(_req: Request, res: Response) {
  const { limit } = res.locals.query as ShowcaseQuery;
  res.set('Cache-Control', SHORT_CACHE);
  sendSuccess(res, await listFeatured(limit));
}

export async function getPopular(_req: Request, res: Response) {
  const { limit } = res.locals.query as ShowcaseQuery;
  res.set('Cache-Control', SHORT_CACHE);
  sendSuccess(res, await listPopular(limit));
}

export async function getDestination(_req: Request, res: Response) {
  const { slug } = res.locals.params as SlugParams;
  res.set('Cache-Control', SHORT_CACHE);
  sendSuccess(res, await getDestinationBySlug(slug));
}
