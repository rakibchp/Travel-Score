import type { Request, Response } from 'express';
import { computeScorecard } from '../services/score.service.js';
import { sendSuccess } from '../utils/response.js';
import type { ScorePreviewBody } from '../validators/score.validators.js';

/** POST /score/preview — scorecard for a guest's browser-held list. Nothing is stored. */
export async function previewScore(_req: Request, res: Response) {
  const { destinationIds, suggestions } = res.locals.body as ScorePreviewBody;
  res.set('Cache-Control', 'private, no-store');
  sendSuccess(res, await computeScorecard(destinationIds, { suggestions }));
}
