import { Types, type PipelineStage } from 'mongoose';
import { Destination } from '../models/Destination.js';
import { DestinationCategory } from '../models/DestinationCategory.js';
import { District } from '../models/District.js';
import { Division } from '../models/Division.js';
import { ApiError } from '../utils/ApiError.js';
import type { PaginationMeta } from '../utils/response.js';
import { escapeRegex, normalizeSearch } from '../utils/searchText.js';
import type { DestinationListQuery } from '../validators/destination.validators.js';

/* ------------------------------------------------------------------ */
/* Shapes returned to clients                                          */
/* ------------------------------------------------------------------ */

type RefSummary = { id: string; slug: string; name: string; nameBn: string };
type CategorySummary = RefSummary & { icon: string | null };
type GeoPoint = { type: 'Point'; coordinates: [number, number] };
type Image = { url: string; publicId?: string; alt?: string };

export type DestinationCard = {
  id: string;
  slug: string;
  name: string;
  nameBn: string;
  shortDescription: string;
  shortDescriptionBn: string | null;
  upazila: { name?: string; nameBn?: string } | null;
  division: RefSummary;
  district: RefSummary;
  category: CategorySummary;
  featuredImage: Image | null;
  location: GeoPoint | null;
  isFeatured: boolean;
};

/** Compact record for map pins and client-side filtering of the whole directory. */
export type DestinationPin = {
  id: string;
  slug: string;
  name: string;
  nameBn: string;
  divisionId: string;
  districtId: string;
  categoryId: string;
  coordinates: [number, number] | null;
};

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const CARD_PROJECTION =
  'name nameBn slug shortDescription shortDescriptionBn upazila division district category featuredImage location isFeatured';

type PopulatedRef = { _id: Types.ObjectId; slug: string; name: string; nameBn: string; icon?: string };

type CardSource = {
  _id: Types.ObjectId;
  slug: string;
  name: string;
  nameBn: string;
  shortDescription: string;
  shortDescriptionBn?: string | null;
  upazila?: { name?: string | null; nameBn?: string | null } | null;
  division: PopulatedRef;
  district: PopulatedRef;
  category: PopulatedRef;
  featuredImage?: Image | null;
  location?: { type?: string; coordinates?: number[] } | null;
  isFeatured?: boolean;
};

const ref = (r: PopulatedRef): RefSummary => ({ id: String(r._id), slug: r.slug, name: r.name, nameBn: r.nameBn });

function toPoint(loc: CardSource['location']): GeoPoint | null {
  const c = loc?.coordinates;
  return c && c.length === 2 ? { type: 'Point', coordinates: [c[0]!, c[1]!] } : null;
}

function toCard(d: CardSource): DestinationCard {
  return {
    id: String(d._id),
    slug: d.slug,
    name: d.name,
    nameBn: d.nameBn,
    shortDescription: d.shortDescription,
    shortDescriptionBn: d.shortDescriptionBn ?? null,
    upazila: d.upazila?.name || d.upazila?.nameBn
      ? { name: d.upazila.name ?? undefined, nameBn: d.upazila.nameBn ?? undefined }
      : null,
    division: ref(d.division),
    district: ref(d.district),
    category: { ...ref(d.category), icon: d.category.icon ?? null },
    featuredImage: d.featuredImage?.url ? d.featuredImage : null,
    location: toPoint(d.location),
    isFeatured: Boolean(d.isFeatured),
  };
}

const CARD_POPULATE = [
  { path: 'division', select: 'name nameBn slug' },
  { path: 'district', select: 'name nameBn slug' },
  { path: 'category', select: 'name nameBn slug icon' },
];

async function idBySlug(model: typeof Division | typeof District | typeof DestinationCategory, slug: string, label: string) {
  const doc = await (model as typeof Division).findOne({ slug }).select('_id').lean();
  if (!doc) throw ApiError.notFound(`${label} not found: ${slug}`);
  return doc._id;
}

/* ------------------------------------------------------------------ */
/* Queries                                                             */
/* ------------------------------------------------------------------ */

export async function listDestinations(query: DestinationListQuery): Promise<{ items: DestinationCard[]; meta: PaginationMeta }> {
  const filter: Record<string, unknown> = { isActive: true };

  const [divisionId, districtId, categoryId] = await Promise.all([
    query.division ? idBySlug(Division, query.division, 'Division') : undefined,
    query.district ? idBySlug(District, query.district, 'District') : undefined,
    query.category ? idBySlug(DestinationCategory, query.category, 'Category') : undefined,
  ]);
  if (divisionId) filter.division = divisionId;
  if (districtId) filter.district = districtId;
  if (categoryId) filter.category = categoryId;

  if (query.ids) filter._id = { $in: query.ids.map((id) => new Types.ObjectId(id)) };
  if (query.excludeIds) filter._id = { $nin: query.excludeIds.map((id) => new Types.ObjectId(id)) };

  const q = query.q ? normalizeSearch(query.q) : '';
  if (q) filter.searchText = { $regex: escapeRegex(q) };

  const sort: Record<string, 1 | -1> =
    query.sort === 'name' ? { name: 1, _id: 1 } : { popularity: -1, isFeatured: -1, name: 1, _id: 1 };

  const skip = (query.page - 1) * query.limit;

  const [docs, total] = await Promise.all([
    Destination.find(filter).select(CARD_PROJECTION).sort(sort).skip(skip).limit(query.limit).populate(CARD_POPULATE).lean<CardSource[]>(),
    Destination.countDocuments(filter),
  ]);

  return {
    items: docs.map(toCard),
    meta: { page: query.page, limit: query.limit, total, totalPages: Math.max(1, Math.ceil(total / query.limit)) },
  };
}

/** Every active destination as a compact pin — powers the map and client-side counts. */
export async function listPins(): Promise<DestinationPin[]> {
  const docs = await Destination.find({ isActive: true })
    .select('name nameBn slug division district category location')
    .sort({ name: 1 })
    .lean();

  return docs.map((d) => ({
    id: String(d._id),
    slug: d.slug,
    name: d.name,
    nameBn: d.nameBn,
    divisionId: String(d.division),
    districtId: String(d.district),
    categoryId: String(d.category),
    coordinates:
      d.location?.coordinates && d.location.coordinates.length === 2
        ? [d.location.coordinates[0]!, d.location.coordinates[1]!]
        : null,
  }));
}

export async function listFeatured(limit: number): Promise<DestinationCard[]> {
  const docs = await Destination.find({ isActive: true, isFeatured: true })
    .select(CARD_PROJECTION)
    .sort({ popularity: -1, name: 1 })
    .limit(limit)
    .populate(CARD_POPULATE)
    .lean<CardSource[]>();
  return docs.map(toCard);
}

/**
 * Most-visited destinations. Before anyone has saved visits (popularity all 0),
 * featured destinations come first so the section is never empty.
 */
export async function listPopular(limit: number): Promise<DestinationCard[]> {
  const docs = await Destination.find({ isActive: true })
    .select(CARD_PROJECTION)
    .sort({ popularity: -1, isFeatured: -1, name: 1 })
    .limit(limit)
    .populate(CARD_POPULATE)
    .lean<CardSource[]>();
  return docs.map(toCard);
}

export async function getDestinationBySlug(slug: string) {
  const doc = await Destination.findOne({ slug, isActive: true })
    .select('-searchText')
    .populate(CARD_POPULATE)
    .lean<
    CardSource & {
      description?: string;
      descriptionBn?: string;
      significance?: string;
      significanceBn?: string;
      visitingInfo?: Record<string, string>;
      images?: Image[];
      popularity?: number;
    }
  >();
  if (!doc) throw ApiError.notFound('Destination not found');

  // Nearby: geo-nearest when we have coordinates, otherwise others in the same district.
  const coords = doc.location?.coordinates;
  const nearbyPipeline: PipelineStage[] =
    coords && coords.length === 2
      ? [
          {
            $geoNear: {
              near: { type: 'Point', coordinates: [coords[0]!, coords[1]!] },
              distanceField: 'distanceMeters',
              query: { isActive: true, _id: { $ne: doc._id } },
              spherical: true,
            },
          },
          { $limit: 6 },
        ]
      : [{ $match: { isActive: true, district: doc.district._id, _id: { $ne: doc._id } } }, { $limit: 6 }];

  const nearbyRaw = await Destination.aggregate<{ _id: Types.ObjectId; distanceMeters?: number }>([
    ...nearbyPipeline,
    { $project: { _id: 1, distanceMeters: 1 } },
  ]);
  const nearbyDocs = await Destination.find({ _id: { $in: nearbyRaw.map((n) => n._id) } })
    .select(CARD_PROJECTION)
    .populate(CARD_POPULATE)
    .lean<CardSource[]>();
  const byId = new Map(nearbyDocs.map((d) => [String(d._id), d]));
  const nearby = nearbyRaw
    .map((n) => {
      const d = byId.get(String(n._id));
      return d ? { ...toCard(d), distanceKm: n.distanceMeters !== undefined ? Math.round(n.distanceMeters / 100) / 10 : null } : null;
    })
    .filter((x): x is DestinationCard & { distanceKm: number | null } => x !== null);

  return {
    ...toCard(doc),
    description: doc.description ?? null,
    descriptionBn: doc.descriptionBn ?? null,
    significance: doc.significance ?? null,
    significanceBn: doc.significanceBn ?? null,
    visitingInfo: doc.visitingInfo ?? null,
    images: doc.images ?? [],
    nearby,
  };
}

/** Cards for specific ids, returned in the order given (inactive/unknown ids are skipped). */
export async function listDestinationCards(ids: string[]): Promise<DestinationCard[]> {
  if (ids.length === 0) return [];
  const docs = await Destination.find({ _id: { $in: ids.map((id) => new Types.ObjectId(id)) }, isActive: true })
    .select(CARD_PROJECTION)
    .populate(CARD_POPULATE)
    .lean<CardSource[]>();
  const byId = new Map(docs.map((d) => [String(d._id), d]));
  return ids.map((id) => byId.get(id)).filter((d): d is CardSource => Boolean(d)).map(toCard);
}
