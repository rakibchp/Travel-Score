import { Types } from 'mongoose';
import { Destination } from '../models/Destination.js';
import { DestinationCategory } from '../models/DestinationCategory.js';
import { District } from '../models/District.js';
import { Division } from '../models/Division.js';
import { listDestinationCards, type DestinationCard } from './destination.service.js';

/**
 * Travel score engine.
 *
 * score = number of distinct, ACTIVE destinations in the given id list.
 * Denominators count active destinations only, so deactivating a destination
 * removes it from both sides and percentages stay ≤ 100%.
 *
 * The same function serves guests (ids from the browser, POST /score/preview)
 * and, from Phase 4, signed-in users (ids loaded from their travel records).
 * The client never sends a score — only ids, which are validated here.
 */

type Bucket = { id: string; slug: string; name: string; nameBn: string; visited: number; total: number };

export type Scorecard = {
  score: number;
  totalDestinations: number;
  percentage: number;
  districtsExplored: number;
  totalDistricts: number;
  divisionsExplored: number;
  totalDivisions: number;
  categoriesExplored: number;
  totalCategories: number;
  byDivision: Bucket[];
  byDistrict: Array<Bucket & { divisionId: string }>;
  byCategory: Array<Bucket & { icon: string | null }>;
  /** Ids that were sent but don't count (unknown, inactive or malformed). Clients should drop them. */
  ignoredIds: string[];
  /** "Where next?" — unvisited destinations, favouring featured places in places you haven't explored much. */
  suggestions: DestinationCard[];
};

/* ------------------------------------------------------------------ */
/* Totals (all active destinations), cached briefly per instance       */
/* ------------------------------------------------------------------ */

type Totals = {
  all: number;
  divisions: Array<{ _id: Types.ObjectId; slug: string; name: string; nameBn: string; order: number }>;
  districts: Array<{ _id: Types.ObjectId; slug: string; name: string; nameBn: string; division: Types.ObjectId }>;
  categories: Array<{ _id: Types.ObjectId; slug: string; name: string; nameBn: string; icon?: string | null; order: number }>;
  perDivision: Map<string, number>;
  perDistrict: Map<string, number>;
  perCategory: Map<string, number>;
};

const TOTALS_TTL_MS = 60_000;
let totalsCache: { at: number; value: Promise<Totals> } | null = null;

/** Called after admin edits (Phase 7) so totals are fresh immediately. */
export function invalidateScoreTotals() {
  totalsCache = null;
}

async function loadTotals(): Promise<Totals> {
  const [divisions, districts, categories, facets] = await Promise.all([
    Division.find().select('slug name nameBn order').sort({ order: 1, name: 1 }).lean(),
    District.find().select('slug name nameBn division').sort({ name: 1 }).lean(),
    DestinationCategory.find({ isActive: true }).select('slug name nameBn icon order').sort({ order: 1, name: 1 }).lean(),
    Destination.aggregate<{
      all: Array<{ n: number }>;
      division: Array<{ _id: Types.ObjectId; n: number }>;
      district: Array<{ _id: Types.ObjectId; n: number }>;
      category: Array<{ _id: Types.ObjectId; n: number }>;
    }>([
      { $match: { isActive: true } },
      {
        $facet: {
          all: [{ $count: 'n' }],
          division: [{ $group: { _id: '$division', n: { $sum: 1 } } }],
          district: [{ $group: { _id: '$district', n: { $sum: 1 } } }],
          category: [{ $group: { _id: '$category', n: { $sum: 1 } } }],
        },
      },
    ]),
  ]);
  const f = facets[0]!;
  const toMap = (rows: Array<{ _id: Types.ObjectId; n: number }>) => new Map(rows.map((r) => [String(r._id), r.n]));
  return {
    all: f.all[0]?.n ?? 0,
    divisions,
    districts,
    categories,
    perDivision: toMap(f.division),
    perDistrict: toMap(f.district),
    perCategory: toMap(f.category),
  };
}

function getTotals(): Promise<Totals> {
  const now = Date.now();
  if (!totalsCache || now - totalsCache.at > TOTALS_TTL_MS) {
    const value = loadTotals().catch((err: unknown) => {
      totalsCache = null; // don't cache failures
      throw err;
    });
    totalsCache = { at: now, value };
  }
  return totalsCache.value;
}

/* ------------------------------------------------------------------ */
/* Score                                                               */
/* ------------------------------------------------------------------ */

export const percent = (part: number, total: number) => (total > 0 ? Math.round((part / total) * 1000) / 10 : 0);

export async function computeScorecard(rawIds: string[], options: { suggestions?: number } = {}): Promise<Scorecard> {
  const unique = [...new Set(rawIds)];
  const validObjectIds = unique.filter((id) => Types.ObjectId.isValid(id) && /^[a-f0-9]{24}$/i.test(id));

  const [totals, visitedDocs] = await Promise.all([
    getTotals(),
    validObjectIds.length
      ? Destination.find({ _id: { $in: validObjectIds.map((id) => new Types.ObjectId(id)) }, isActive: true })
          .select('_id division district category')
          .lean()
      : Promise.resolve([]),
  ]);

  const counted = new Set(visitedDocs.map((d) => String(d._id)));
  const ignoredIds = unique.filter((id) => !counted.has(id));

  const vDivision = new Map<string, number>();
  const vDistrict = new Map<string, number>();
  const vCategory = new Map<string, number>();
  const bump = (m: Map<string, number>, k: string) => m.set(k, (m.get(k) ?? 0) + 1);
  for (const d of visitedDocs) {
    bump(vDivision, String(d.division));
    bump(vDistrict, String(d.district));
    bump(vCategory, String(d.category));
  }

  const score = visitedDocs.length;

  const byDivision = totals.divisions.map((d) => ({
    id: String(d._id),
    slug: d.slug,
    name: d.name,
    nameBn: d.nameBn,
    visited: vDivision.get(String(d._id)) ?? 0,
    total: totals.perDivision.get(String(d._id)) ?? 0,
  }));
  const byDistrict = totals.districts.map((d) => ({
    id: String(d._id),
    slug: d.slug,
    name: d.name,
    nameBn: d.nameBn,
    divisionId: String(d.division),
    visited: vDistrict.get(String(d._id)) ?? 0,
    total: totals.perDistrict.get(String(d._id)) ?? 0,
  }));
  const byCategory = totals.categories.map((c) => ({
    id: String(c._id),
    slug: c.slug,
    name: c.name,
    nameBn: c.nameBn,
    icon: c.icon ?? null,
    visited: vCategory.get(String(c._id)) ?? 0,
    total: totals.perCategory.get(String(c._id)) ?? 0,
  }));

  const suggestions = options.suggestions
    ? await suggestNext({ visited: counted, byDistrict, byDivision, limit: options.suggestions })
    : [];

  return {
    score,
    totalDestinations: totals.all,
    percentage: percent(score, totals.all),
    districtsExplored: vDistrict.size,
    totalDistricts: totals.districts.length,
    divisionsExplored: vDivision.size,
    totalDivisions: totals.divisions.length,
    categoriesExplored: vCategory.size,
    totalCategories: totals.categories.length,
    byDivision,
    byDistrict,
    byCategory,
    ignoredIds,
    suggestions,
  };
}

/* ------------------------------------------------------------------ */
/* "Where next?"                                                       */
/* ------------------------------------------------------------------ */

/**
 * Rank unvisited destinations:
 *  1. featured places first (the must-sees),
 *  2. then places in districts the user hasn't explored at all,
 *  3. then in the divisions where their completion is lowest,
 * picking at most one per district so the list feels varied.
 */
async function suggestNext(input: {
  visited: Set<string>;
  byDistrict: Array<{ id: string; visited: number; total: number; divisionId: string }>;
  byDivision: Array<{ id: string; visited: number; total: number }>;
  limit: number;
}): Promise<DestinationCard[]> {
  const candidates = await Destination.find({
    isActive: true,
    _id: { $nin: [...input.visited].map((id) => new Types.ObjectId(id)) },
  })
    .select('_id district division isFeatured popularity name')
    .lean();

  const districtVisited = new Map(input.byDistrict.map((d) => [d.id, d.visited]));
  const divisionPct = new Map(input.byDivision.map((d) => [d.id, d.total ? d.visited / d.total : 1]));

  const ranked = candidates
    .map((c) => {
      let rank = 0;
      if (c.isFeatured) rank += 100;
      if ((districtVisited.get(String(c.district)) ?? 0) === 0) rank += 30;
      rank += (1 - (divisionPct.get(String(c.division)) ?? 1)) * 20;
      rank += Math.min(c.popularity ?? 0, 1000) / 100;
      return { id: String(c._id), district: String(c.district), rank, name: c.name };
    })
    .sort((a, b) => b.rank - a.rank || a.name.localeCompare(b.name));

  const picked: string[] = [];
  const usedDistricts = new Set<string>();
  for (const c of ranked) {
    if (picked.length >= input.limit) break;
    if (usedDistricts.has(c.district)) continue;
    usedDistricts.add(c.district);
    picked.push(c.id);
  }
  return listDestinationCards(picked);
}
