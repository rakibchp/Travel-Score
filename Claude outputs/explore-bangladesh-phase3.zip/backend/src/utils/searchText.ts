/**
 * Normalization shared by stored search text and incoming queries.
 * NFC makes composed/decomposed Bengali letters (e.g. য় vs য + ়) compare equal;
 * lowercasing handles English; whitespace is collapsed.
 */
export function normalizeSearch(input: string): string {
  return input.normalize('NFC').toLowerCase().replace(/\s+/g, ' ').trim();
}

export function buildSearchText(parts: Array<string | null | undefined>): string {
  return normalizeSearch(parts.filter(Boolean).join(' '));
}

/** Escape user input for safe use inside a RegExp. */
export function escapeRegex(input: string): string {
  return input.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
