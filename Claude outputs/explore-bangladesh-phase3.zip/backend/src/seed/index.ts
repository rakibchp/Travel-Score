/**
 * npm run seed — idempotent seed of reference data.
 *
 * Upserts by slug, so it is safe to run repeatedly and will update names or
 * Bengali spellings if the JSON changes. It never deletes anything.
 *
 * Destinations: content fields (names, descriptions, coordinates…) are updated
 * from the JSON on every run; isActive / isFeatured / popularity are only set
 * when a destination is first inserted, so admin changes to those survive a re-seed.
 * Pass --insert-only to add new destinations without touching existing ones.
 */
import { readdirSync, readFileSync } from 'node:fs';
import { connectDB, disconnectDB } from '../config/db.js';
import { Destination } from '../models/Destination.js';
import { DestinationCategory } from '../models/DestinationCategory.js';
import { District } from '../models/District.js';
import { Division } from '../models/Division.js';
import { buildSearchText } from '../utils/searchText.js';
import { slugify } from '../utils/slugify.js';

type DivisionSeed = { name: string; nameBn: string; order: number };
type DistrictSeed = { name: string; nameBn: string; division: string };
type CategorySeed = { name: string; nameBn: string; icon: string; order: number };
type DestinationSeed = {
  name: string;
  nameBn: string;
  district: string;
  upazila?: [string, string];
  category: string;
  lat: number;
  lng: number;
  short: string;
  shortBn?: string;
  description?: string;
  descriptionBn?: string;
  featured?: boolean;
  aliases?: string[];
};

/** Paths under /destinations/ that are routes, so no destination may use them as a slug. */
const RESERVED_SLUGS = new Set(['pins', 'featured', 'popular']);
const insertOnly = process.argv.includes('--insert-only');

function loadJson<T>(file: string): T {
  return JSON.parse(readFileSync(new URL(`./data/${file}`, import.meta.url), 'utf8')) as T;
}

async function seedDivisions() {
  const data = loadJson<DivisionSeed[]>('divisions.json');
  if (data.length !== 8) throw new Error(`Expected 8 divisions, found ${data.length}`);

  await Division.bulkWrite(
    data.map((d) => ({
      updateOne: {
        filter: { slug: slugify(d.name) },
        update: { $set: { name: d.name, nameBn: d.nameBn, order: d.order, slug: slugify(d.name) } },
        upsert: true,
      },
    })),
  );
  console.log(`   divisions: ${data.length}`);
}

async function seedDistricts() {
  const data = loadJson<DistrictSeed[]>('districts.json');
  if (data.length !== 64) throw new Error(`Expected 64 districts, found ${data.length}`);

  const divisions = await Division.find().select('_id name').lean();
  const divisionIdByName = new Map(divisions.map((d) => [d.name, d._id]));

  const ops = data.map((d) => {
    const divisionId = divisionIdByName.get(d.division);
    if (!divisionId) throw new Error(`District "${d.name}" references unknown division "${d.division}"`);
    const slug = slugify(d.name);
    return {
      updateOne: {
        filter: { slug },
        update: { $set: { name: d.name, nameBn: d.nameBn, slug, division: divisionId } },
        upsert: true,
      },
    };
  });

  await District.bulkWrite(ops);
  console.log(`   districts: ${data.length}`);
}

async function seedCategories() {
  const data = loadJson<CategorySeed[]>('categories.json');
  await DestinationCategory.bulkWrite(
    data.map((c) => {
      const slug = slugify(c.name);
      return {
        updateOne: {
          filter: { slug },
          update: {
            $set: { name: c.name, nameBn: c.nameBn, slug, icon: c.icon, order: c.order },
            $setOnInsert: { isActive: true },
          },
          upsert: true,
        },
      };
    }),
  );
  console.log(`   categories: ${data.length}`);
}

async function seedDestinations() {
  const dir = new URL('./data/destinations/', import.meta.url);
  const files = readdirSync(dir).filter((f) => f.endsWith('.json')).sort();
  const data = files.flatMap((f) => JSON.parse(readFileSync(new URL(f, dir), 'utf8')) as DestinationSeed[]);

  const [districts, categories] = await Promise.all([
    District.find().select('_id name nameBn division').lean(),
    DestinationCategory.find().select('_id slug').lean(),
  ]);
  const districtByName = new Map(districts.map((d) => [d.name, d]));
  const categoryBySlug = new Map(categories.map((c) => [c.slug, c._id]));

  const seen = new Set<string>();
  const ops = data.map((d) => {
    const district = districtByName.get(d.district);
    if (!district) throw new Error(`Destination "${d.name}" references unknown district "${d.district}"`);
    const categoryId = categoryBySlug.get(d.category);
    if (!categoryId) throw new Error(`Destination "${d.name}" references unknown category "${d.category}"`);
    const slug = slugify(d.name);
    if (!slug || RESERVED_SLUGS.has(slug)) throw new Error(`Destination "${d.name}" has an invalid slug "${slug}"`);
    if (seen.has(slug)) throw new Error(`Duplicate destination slug "${slug}"`);
    seen.add(slug);
    if (!(d.lng >= 88 && d.lng <= 92.8 && d.lat >= 20.5 && d.lat <= 26.7)) {
      throw new Error(`Destination "${d.name}" has coordinates outside Bangladesh: ${d.lat}, ${d.lng}`);
    }

    const content = {
      name: d.name,
      nameBn: d.nameBn,
      slug,
      division: district.division,
      district: district._id,
      upazila: d.upazila ? { name: d.upazila[0], nameBn: d.upazila[1] } : undefined,
      category: categoryId,
      shortDescription: d.short,
      shortDescriptionBn: d.shortBn,
      description: d.description,
      descriptionBn: d.descriptionBn,
      location: { type: 'Point' as const, coordinates: [d.lng, d.lat] },
      aliases: d.aliases ?? [],
      searchText: buildSearchText([
        d.name,
        d.nameBn,
        ...(d.aliases ?? []),
        district.name,
        district.nameBn,
        d.upazila?.[0],
        d.upazila?.[1],
      ]),
    };
    const onInsert = { isActive: true, isFeatured: Boolean(d.featured), popularity: 0 };

    return {
      updateOne: {
        filter: { slug },
        update: insertOnly ? { $setOnInsert: { ...content, ...onInsert } } : { $set: content, $setOnInsert: onInsert },
        upsert: true,
        // In insert-only mode existing documents must not even get a new updatedAt.
        timestamps: !insertOnly,
      },
    };
  });

  const result = await Destination.bulkWrite(ops);
  console.log(
    `   destinations: ${data.length} (${result.upsertedCount} new, ${result.matchedCount} ${insertOnly ? 'existing left unchanged' : 'existing refreshed'})`,
  );
}

try {
  await connectDB();
  console.log('🌱 Seeding reference data…');
  // Make sure unique indexes exist before upserting (autoIndex is off in production).
  await Promise.all([
    Division.syncIndexes(),
    District.syncIndexes(),
    DestinationCategory.syncIndexes(),
    Destination.syncIndexes(),
  ]);
  await seedDivisions();
  await seedDistricts();
  await seedCategories();
  await seedDestinations();
  console.log('✅ Seed complete');
} catch (err) {
  console.error('❌ Seed failed:', err instanceof Error ? err.message : err);
  process.exitCode = 1;
} finally {
  await disconnectDB();
}
